﻿
<?php $__env->startSection('title', 'Offres d\'emploi au Bénin, CDI, CDD, Stage, Bourse à Cotonou | Emploi Bouge Bénin'); ?>
<?php $__env->startSection('description', 'Consultez toutes les offres d\'emploi au Bénin : CDI, CDD, stages, bourses et freelance à Cotonou et dans tout le Bénin. Annonces vérifiées, mise à jour quotidienne.'); ?>
<?php $__env->startSection('og_title', 'Offres d\'emploi au Bénin, Annonces CDI, CDD, Stages | Emploi Bouge Bénin'); ?>
<?php $__env->startSection('og_description', 'Parcourez les offres d\'emploi au Bénin. Trouvez un CDI, CDD, stage ou bourse à Cotonou et dans tout le Bénin. Candidature en ligne.'); ?>

<?php $__env->startSection('jsonld'); ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {"@type":"ListItem","position":1,"name":"Accueil","item":"<?php echo e(route('home')); ?>"},
    {"@type":"ListItem","position":2,"name":"Offres d'emploi","item":"<?php echo e(route('offre.list')); ?>"}
  ]
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/offre/list-offre.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/searchable-select.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="ol-hero">
  <h1 class="ol-hero__title">Offres d'emploi au Bénin</h1>
  <p class="ol-hero__sub"><?php echo e($offres->total()); ?> offre<?php echo e($offres->total() !== 1 ? 's' : ''); ?> disponible<?php echo e($offres->total() !== 1 ? 's' : ''); ?>, mise à jour en continu</p>
  <form method="GET" action="<?php echo e(route('offre.list')); ?>" class="ol-hero__search">
    <?php $__currentLoopData = request()->except(['q','page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input type="text" name="q" value="<?php echo e(request('q')); ?>"
           placeholder="Titre, entreprise, compétence…"
           class="ol-hero__input" autocomplete="off">
    <button type="submit" class="ol-hero__btn">
      <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><path stroke-linecap="round" d="m21 21-4.35-4.35"/></svg>
      Rechercher
    </button>
  </form>
</div>


<div class="ol-tabs">
  <a href="<?php echo e(route('offre.list', request()->except(['type','page']))); ?>"
     class="ol-tab <?php echo e(!request('type') ? 'active' : ''); ?>">Tous</a>
  <?php $__currentLoopData = $typeContratsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
      $tabLabel = Str::before(Str::before($tc->libelle, ' : '), ' / ');
    ?>
    <a href="<?php echo e(route('offre.list', array_merge(request()->except(['type','page']), ['type' => $tc->code]))); ?>"
       class="ol-tab <?php echo e(request('type') === $tc->code ? 'active' : ''); ?>"><?php echo e($tabLabel); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="ol-body">
  <div class="ol-wrap">

    
    <button class="ol-filter-toggle" id="ol-filter-toggle" aria-expanded="false">
      <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 4a1 1 0 0 1 1-1h16a1 1 0 0 1 .78 1.625L14 13.197V19a1 1 0 0 1-1.447.894l-4-2A1 1 0 0 1 8 17v-3.803L3.22 5.625A1 1 0 0 1 3 4z"/></svg>
      <span id="ol-toggle-label">Afficher les filtres</span>
      <?php $hasFilters = request()->hasAny(['metier','niveau_experience','niveau_etude','localisation','secteur','competence']); ?>
      <?php if($hasFilters): ?>
        <span style="margin-left:auto;background:#185FA5;color:#fff;border-radius:99px;padding:2px 8px;font-size:11px">Actifs</span>
      <?php endif; ?>
    </button>

    
    <aside class="ol-sidebar<?php echo e($hasFilters ? ' open' : ''); ?>" id="ol-sidebar">
      <div class="ol-sidebar__head">
        <svg class="ol-sidebar__head-icon" width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 4a1 1 0 0 1 1-1h16a1 1 0 0 1 .78 1.625L14 13.197V19a1 1 0 0 1-1.447.894l-4-2A1 1 0 0 1 8 17v-3.803L3.22 5.625A1 1 0 0 1 3 4z"/></svg>
        <span class="ol-sidebar__head-title">Affiner la recherche</span>
      </div>

      <form method="GET" action="<?php echo e(route('offre.list')); ?>">
        
        <?php if(request('q')): ?>
          <input type="hidden" name="q" value="<?php echo e(request('q')); ?>">
        <?php endif; ?>
        <?php if(request('type')): ?>
          <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
        <?php endif; ?>

        
        
        <div class="ol-fgroup">
          <label for="f-metier">Métier</label>
          <select id="f-metier" name="metier" class="ol-fselect" onchange="this.form.submit()" data-searchable>
            <option value="">Tous les métiers</option>
            <?php $__currentLoopData = $metiersList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($m->nom); ?>" <?php echo e(request('metier') === $m->nom ? 'selected' : ''); ?>><?php echo e($m->nom); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="ol-fgroup">
          <label for="f-exp">Niveau d'expérience</label>
          <select id="f-exp" name="niveau_experience" class="ol-fselect" onchange="this.form.submit()" data-searchable>
            <option value="">Toute expérience</option>
            <?php $__currentLoopData = $niveauxExpList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($ne->code); ?>" <?php echo e(request('niveau_experience') === $ne->code ? 'selected' : ''); ?>><?php echo e($ne->libelle); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="ol-fgroup">
          <label for="f-etude">Niveau d'études</label>
          <select id="f-etude" name="niveau_etude" class="ol-fselect" onchange="this.form.submit()" data-searchable>
            <option value="">Tous niveaux</option>
            <?php $__currentLoopData = $niveauxEtudeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($ne->code); ?>" <?php echo e(request('niveau_etude') === $ne->code ? 'selected' : ''); ?>><?php echo e($ne->libelle); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="ol-fgroup">
          <label for="f-loc">Région / Ville</label>
          <select id="f-loc" name="localisation" class="ol-fselect" onchange="this.form.submit()" data-searchable>
            <option value="">Toutes les régions</option>
            <?php $__currentLoopData = $regionsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($r->nom); ?>" <?php echo e(request('localisation') === $r->nom ? 'selected' : ''); ?>><?php echo e($r->nom); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="ol-fgroup">
          <label for="f-secteur">Secteur d'activité</label>
          <select id="f-secteur" name="secteur" class="ol-fselect" onchange="this.form.submit()" data-searchable>
            <option value="">Tous les secteurs</option>
            <?php $__currentLoopData = $secteursList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($s->libelle); ?>" <?php echo e(request('secteur') === $s->libelle ? 'selected' : ''); ?>><?php echo e($s->libelle); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="ol-fgroup">
          <label for="f-comp">Compétence</label>
          <select id="f-comp" name="competence" class="ol-fselect" onchange="this.form.submit()" data-searchable>
            <option value="">Toutes les compétences</option>
            <?php $__currentLoopData = $competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($comp->slug); ?>" <?php echo e(request('competence') === $comp->slug ? 'selected' : ''); ?>>
                <?php echo e($comp->nom); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="ol-sidebar__actions">
          <?php if(request()->hasAny(['localisation','secteur','competence','metier','niveau_experience','niveau_etude'])): ?>
            <a href="<?php echo e(route('offre.list', request()->only(['q','type']))); ?>" class="ol-btn-reset">
              Réinitialiser
            </a>
          <?php endif; ?>
        </div>
      </form>
    </aside>

    
    <div>
      
      <div class="ol-bar">
        <p class="ol-bar__count">
          <span><?php echo e($offres->total()); ?></span> offre<?php echo e($offres->total() !== 1 ? 's' : ''); ?>

          <?php if(request()->hasAny(['q','type','localisation','secteur','competence','metier','niveau_experience','niveau_etude'])): ?>
            trouvée<?php echo e($offres->total() !== 1 ? 's' : ''); ?>

          <?php else: ?>
            disponible<?php echo e($offres->total() !== 1 ? 's' : ''); ?>

          <?php endif; ?>
        </p>
        <div class="ol-bar__active-filters">
          <?php if(request('q')): ?>
            <span class="ol-chip"><?php echo e(request('q')); ?></span>
          <?php endif; ?>
          <?php if(request('type')): ?>
            <span class="ol-chip"><?php echo e(request('type')); ?></span>
          <?php endif; ?>
          <?php if(request('localisation')): ?>
            <span class="ol-chip"><?php echo e(request('localisation')); ?></span>
          <?php endif; ?>
          <?php if(request('secteur')): ?>
            <span class="ol-chip"><?php echo e(request('secteur')); ?></span>
          <?php endif; ?>
        </div>
      </div>

      
      <div class="ol-list">
        <?php $__empty_1 = true; $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <a href="<?php echo e(route('offre.detail', $offre)); ?>" class="ol-card" style="display:block;background:#fff;border:1.5px solid #e8edf3;border-radius:16px;padding:20px 22px;text-decoration:none;transition:box-shadow .18s,transform .18s;box-shadow:0 2px 8px rgba(4,44,83,.06)"
             onmouseover="this.style.boxShadow='0 8px 28px rgba(4,44,83,.13)';this.style.transform='translateY(-2px)'"
             onmouseout="this.style.boxShadow='0 2px 8px rgba(4,44,83,.06)';this.style.transform='none'">

            
            <div style="display:flex;align-items:flex-start;gap:14px;margin-bottom:12px">
              
              <div style="flex-shrink:0;width:52px;height:52px;border-radius:12px;background:linear-gradient(135deg,#e8f0fe,#dbeafe);border:1.5px solid #c7d7f8;display:flex;align-items:center;justify-content:center;overflow:hidden">
                <?php if($offre->logo): ?>
                  <img src="<?php echo e(asset('storage/' . $offre->logo)); ?>" alt="<?php echo e($offre->entreprise); ?>" style="width:100%;height:100%;object-fit:contain;padding:4px">
                <?php else: ?>
                  <span style="font-size:1.15rem;font-weight:800;color:#185FA5;letter-spacing:-1px"><?php echo e(strtoupper(substr($offre->entreprise, 0, 2))); ?></span>
                <?php endif; ?>
              </div>
              
              <div style="flex:1;min-width:0">
                <div style="font-size:15px;font-weight:700;color:#042C53;line-height:1.3;margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo e($offre->titre); ?></div>
                <div style="font-size:12.5px;color:#185FA5;font-weight:600"><?php echo e($offre->entreprise); ?></div>
              </div>
              
              <div style="flex-shrink:0;font-size:11px;color:#94a3b8;white-space:nowrap"><?php echo e($offre->created_at->diffForHumans()); ?></div>
            </div>

            
            <p style="font-size:13px;color:#64748b;line-height:1.6;margin:0 0 14px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden"><?php echo e(Str::limit(strip_tags($offre->description), 120)); ?></p>

            
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
              <?php if($offre->type): ?>
                <span style="font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe"><?php echo e($offre?->type?->libelle); ?></span>
              <?php endif; ?>
              <span style="font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;background:#f1f5f9;color:#475569;display:inline-flex;align-items:center;gap:4px">
                <svg width="10" height="10" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a2 2 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/></svg>
                <?php echo e($offre->localisation); ?>

              </span>
              <?php if($offre->salaire): ?>
                <span style="font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0"><?php echo e($offre->salaire); ?> Fcfa</span>
              <?php endif; ?>
              <?php if($offre->date_limite): ?>
                <span style="font-size:11px;color:#f59e0b;font-weight:600;margin-left:auto">Expire <?php echo e($offre->date_limite->format('d/m')); ?></span>
              <?php endif; ?>
              <span style="font-size:12px;font-weight:700;color:#185FA5;margin-left:<?php echo e($offre->date_limite ? '4px' : 'auto'); ?>;display:inline-flex;align-items:center;gap:3px">
                Voir l'offre
                <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
              </span>
            </div>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <?php
            if (request('metier')) {
              $emptyTitle = 'Aucune offre de "' . request('metier') . '" pour l\'instant';
              $emptySub   = 'Ce métier est très demandé ! De nouvelles offres arrivent chaque jour. Déposez votre CV dès maintenant pour être contacté directement par les recruteurs.';
            } elseif (request('q')) {
              $emptyTitle = 'Aucune offre pour « ' . request('q') . ' »';
              $emptySub   = 'Cette opportunité n\'est pas encore publiée, mais de nouvelles offres arrivent chaque jour. Activez une alerte pour ne pas la manquer !';
            } elseif (request('type')) {
              $emptyTitle = 'Aucun ' . request('type') . ' disponible pour l\'instant';
              $emptySub   = 'De nouvelles offres de ce type sont publiées régulièrement. Revenez bientôt ou consultez toutes les offres disponibles.';
            } elseif (request('localisation')) {
              $emptyTitle = 'Aucune offre à ' . request('localisation') . ' pour l\'instant';
              $emptySub   = 'Cette ville est en pleine croissance économique ! Revenez bientôt ou explorez les villes voisines, de nombreuses offres sont ouvertes à la mobilité.';
            } elseif (request('secteur')) {
              $emptyTitle = 'Pas encore d\'offres en ' . request('secteur');
              $emptySub   = 'Ce secteur recrute activement au Bénin ! Soyez parmi les premiers à candidater dès la publication. Déposez votre CV pour être visible.';
            } elseif (request('niveau_experience')) {
              $libExp = $niveauxExpList->firstWhere('code', request('niveau_experience'));
              $emptyTitle = 'Aucune offre pour ce niveau d\'expérience pour l\'instant';
              $emptySub   = 'Votre profil de niveau ' . ($libExp?->libelle ?? '') . ' mérite d\'être vu ! Déposez votre CV et laissez les recruteurs venir directement à vous.';
            } elseif (request('niveau_etude')) {
              $libEtude = $niveauxEtudeList->firstWhere('code', request('niveau_etude'));
              $emptyTitle = 'Aucune offre correspondant à ce niveau d\'études pour l\'instant';
              $emptySub   = 'Des offres pour le niveau ' . ($libEtude?->libelle ?? '') . ' arrivent régulièrement. Déposez votre CV pour être parmi les premiers contactés !';
            } elseif (request('competence')) {
              $emptyTitle = 'Aucune offre pour cette compétence pour l\'instant';
              $emptySub   = 'Cette compétence est précieuse et très recherchée par les recruteurs. Déposez votre CV et mettez-la en avant : les offres ne tarderont pas !';
            } else {
              $emptyTitle = 'De nouvelles offres arrivent chaque jour !';
              $emptySub   = 'Notre plateforme est en pleine croissance. Revenez bientôt ou déposez votre CV pour être visible auprès de tous les recruteurs.';
            }
          ?>
          <div class="ol-empty">
            <p class="ol-empty__title"><?php echo e($emptyTitle); ?></p>
            <p class="ol-empty__sub"><?php echo e($emptySub); ?></p>
            <a href="<?php echo e(route('offre.list')); ?>" class="ol-empty__link">Voir toutes les offres</a>
          </div>
        <?php endif; ?>
      </div>

      <?php if($offres->hasPages()): ?>
        <div style="margin-top: 28px">
          <?php echo e($offres->withQueryString()->links()); ?>

        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/searchable-select.js')); ?>"></script>
<script>
(function(){
  var btn = document.getElementById('ol-filter-toggle');
  var sidebar = document.getElementById('ol-sidebar');
  var label = document.getElementById('ol-toggle-label');
  if (!btn || !sidebar) return;
  btn.addEventListener('click', function(){
    var open = sidebar.classList.toggle('open');
    btn.setAttribute('aria-expanded', open);
    label.textContent = open ? 'Masquer les filtres' : 'Afficher les filtres';
  });
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/public/offre/list.blade.php ENDPATH**/ ?>