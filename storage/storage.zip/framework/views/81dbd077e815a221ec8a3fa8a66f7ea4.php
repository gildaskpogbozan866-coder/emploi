<header class="site-header">
  <div class="nav-wrapper">
    <nav class="nav">
      <a href="<?php echo e(route('home')); ?>" class="nav__logo">
        <span class="nav__logo-mark"><img src="<?php echo e(asset('images/Logo.png')); ?>" alt="Emploi Bouge Bénin"></span>
      </a>
      <ul class="nav__links">
        <li><a href="<?php echo e(route('home')); ?>" class="nav__link <?php echo e(request()->routeIs('home') ? 'nav__link--active' : ''); ?>">Accueil</a></li>
        <li><a href="<?php echo e(route('a-propos')); ?>" class="nav__link <?php echo e(request()->routeIs('a-propos') ? 'nav__link--active' : ''); ?>">À propos</a></li>
        <li><a href="<?php echo e(route('service.list')); ?>" class="nav__link <?php echo e(request()->routeIs('service.*') ? 'nav__link--active' : ''); ?>">Services</a></li>
        <li><a href="<?php echo e(route('offre.list')); ?>" class="nav__link <?php echo e(request()->routeIs('offre.*') ? 'nav__link--active' : ''); ?>">Offres d'emploi</a></li>
        <li><a href="<?php echo e(route('publicites.index')); ?>" class="nav__link <?php echo e(request()->routeIs('publicites.*') ? 'nav__link--active' : ''); ?>">Publicités</a></li>
        <li><a href="<?php echo e(route('contact')); ?>" class="nav__link <?php echo e(request()->routeIs('contact') ? 'nav__link--active' : ''); ?>">Contact</a></li>
      </ul>
      <div class="nav__actions">
        <?php if(!auth()->check() || auth()->user()->hasRole('candidat')): ?>
        <a href="<?php echo e(auth()->check() ? route('cv.public.depot') : route('auth.inscription').'?role=candidat'); ?>" class="nav__cta">
          <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
          Déposer mon CV
        </a>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
          <a href="<?php echo e(route('auth.connexion')); ?>" class="nav__btn-outline">Connexion</a>
          <a href="<?php echo e(route('auth.inscription')); ?>" class="nav__btn-filled">Inscription</a>
        <?php else: ?>
          <div style="display:flex;align-items:center;gap:8px">
            <a href="<?php echo e(match(auth()->user()->role) {
              'admin'     => route('admin.dashboard'),
              'recruteur' => route('recruteur.dashboard'),
              'annonceur' => route('annonceur.dashboard'),
              default     => route('candidat.dashboard')
            }); ?>" class="nav__btn-outline" style="display:flex;align-items:center;gap:6px;padding:8px 14px">
              <span style="width:22px;height:22px;border-radius:50%;background:#042C53;color:#fff;font-size:.7rem;font-weight:700;display:flex;align-items:center;justify-content:center"><?php echo e(auth()->user()->initiale); ?></span>
              <span style="max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.85rem"><?php echo e(auth()->user()->prenom); ?></span>
            </a>
            <form method="POST" action="<?php echo e(route('auth.deconnecter')); ?>" style="display:inline">
              <?php echo csrf_field(); ?>
              <button type="submit" style="background:none;border:1px solid #e2e8f0;border-radius:8px;padding:7px 12px;cursor:pointer;font-size:.78rem;color:#64748b;font-family:var(--font-body,Jost,sans-serif)">Sortir</button>
            </form>
          </div>
        <?php endif; ?>
        <button class="nav__hamburger" id="hamburger" aria-label="Ouvrir le menu" aria-expanded="false">
          <span></span><span></span><span></span>
        </button>
      </div>
    </nav>
  </div>

  <div class="nav__mobile" id="mobileMenu">
    <ul class="nav__mobile-list">
      <li><a href="<?php echo e(route('home')); ?>" class="nav__mobile-link">Accueil</a></li>
      <li><a href="<?php echo e(route('a-propos')); ?>" class="nav__mobile-link">À propos</a></li>
      <li><a href="<?php echo e(route('service.list')); ?>" class="nav__mobile-link">Services</a></li>
      <li><a href="<?php echo e(route('offre.list')); ?>" class="nav__mobile-link">Offres d'emploi</a></li>
      <li><a href="<?php echo e(route('publicites.index')); ?>" class="nav__mobile-link">Publicités</a></li>
      <li><a href="<?php echo e(route('contact')); ?>" class="nav__mobile-link">Contact</a></li>
    </ul>
    <?php if(!auth()->check() || auth()->user()->hasRole('candidat')): ?>
    <a href="<?php echo e(auth()->check() ? route('cv.public.depot') : route('auth.inscription').'?role=candidat'); ?>" class="nav__mobile-cta">Déposer mon CV</a>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
      <div class="nav__mobile-auth">
        <a href="<?php echo e(route('auth.connexion')); ?>" class="nav__btn-outline">Connexion</a>
        <a href="<?php echo e(route('auth.inscription')); ?>" class="nav__btn-filled">Inscription</a>
      </div>
    <?php else: ?>
      <div style="gap:8px;flex-direction:column;padding:0 16px 16px">
        <a href="<?php echo e(match(auth()->user()->role) {
          'admin'     => route('admin.dashboard'),
          'recruteur' => route('recruteur.dashboard'),
          'annonceur' => route('annonceur.dashboard'),
          default     => route('candidat.dashboard')
        }); ?>" class="nav__btn-filled" style="text-align:center;display:block">Mon espace</a>
        <form method="POST" action="<?php echo e(route('auth.deconnecter')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" style="background:none;border:1px solid #e2e8f0;border-radius:8px;padding:10px;cursor:pointer;font-size:.85rem;color:#64748b;width:100%;margin-top:8px">Déconnexion</button>
        </form>
      </div>
    <?php endif; ?>
  </div>
</header>
<?php /**PATH C:\xampp\htdocs\emploi\resources\views/components/nav.blade.php ENDPATH**/ ?>