<?php
  $markAllRoute = match(auth()->user()->role) {
    'recruteur'  => 'recruteur.notifications.lues',
    'admin'      => 'admin.notifications.lues',
    'annonceur'  => 'annonceur.notifications.lues',
    default      => 'candidat.notifications.lues',
  };
  $seeAllRoute = match(auth()->user()->role) {
    'candidat'  => route('candidat.notifications'),
    'recruteur' => route('recruteur.notifications'),
    'admin'     => route('admin.notifications'),
    'annonceur' => route('annonceur.notifications'),
    default     => null,
  };
?>

<div class="notif-bell" id="notifBell">
  <button class="notif-bell__btn" id="notifBellBtn" type="button" aria-label="Notifications">
    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
      <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
    </svg>
    <?php if($notifNonLues > 0): ?>
      <span class="notif-bell__badge"><?php echo e($notifNonLues > 9 ? '9+' : $notifNonLues); ?></span>
    <?php endif; ?>
  </button>

  <div class="notif-bell__dropdown" id="notifDropdown">
    <div class="notif-bell__header">
      <span class="notif-bell__header-title">Notifications</span>
      <?php if($notifNonLues > 0): ?>
        <form method="POST" action="<?php echo e(route($markAllRoute)); ?>" style="display:inline">
          <?php echo csrf_field(); ?>
          <button type="submit" class="notif-bell__markall">Tout marquer lu</button>
        </form>
      <?php endif; ?>
    </div>
    <div class="notif-bell__list">
      <?php $__empty_1 = true; $__currentLoopData = $dernierNotifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e($notif->lien ?: '#'); ?>" class="notif-bell__item<?php echo e($notif->lu ? '' : ' notif-bell__item--unread'); ?>">
          <div class="notif-bell__dot<?php echo e($notif->lu ? '' : ' notif-bell__dot--active'); ?>"></div>
          <div class="notif-bell__body">
            <p class="notif-bell__titre"><?php echo e($notif->titre); ?></p>
            <p class="notif-bell__contenu"><?php echo e(\Illuminate\Support\Str::limit($notif->contenu, 80)); ?></p>
            <span class="notif-bell__time"><?php echo e($notif->created_at->diffForHumans()); ?></span>
          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="notif-bell__empty">
          <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;margin:0 auto 8px;opacity:.4"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          Aucune notification
        </div>
      <?php endif; ?>
    </div>
    <?php if($seeAllRoute): ?>
      <a href="<?php echo e($seeAllRoute); ?>" class="notif-bell__seeall">Voir toutes les notifications</a>
    <?php endif; ?>
  </div>
</div>

<script>
(function () {
  const bell = document.getElementById('notifBell');
  const btn  = document.getElementById('notifBellBtn');
  const dd   = document.getElementById('notifDropdown');
  if (!btn || !dd) return;

  function positionDropdown() {
    const rect   = btn.getBoundingClientRect();
    const margin = 8;
    const ddW    = dd.offsetWidth || 340;
    let top   = rect.bottom + margin;
    let right = window.innerWidth - rect.right;

    // Ne pas dépasser le bord gauche de l'écran
    if (rect.right - ddW < 8) {
      right = window.innerWidth - Math.min(rect.right, window.innerWidth - 10);
    }
    // Ne pas dépasser en bas
    const maxH = window.innerHeight - top - 16;
    dd.style.top       = top + 'px';
    dd.style.right     = Math.max(right, 8) + 'px';
    dd.style.maxHeight = Math.max(maxH, 200) + 'px';
  }

  btn.addEventListener('click', function (e) {
    e.stopPropagation();
    const isOpen = dd.classList.contains('open');
    if (!isOpen) positionDropdown();
    dd.classList.toggle('open');
  });

  document.addEventListener('click', function (e) {
    if (!bell.contains(e.target)) dd.classList.remove('open');
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') dd.classList.remove('open');
  });

  window.addEventListener('resize', function () {
    if (dd.classList.contains('open')) positionDropdown();
  });
})();
</script>
<?php /**PATH C:\xampp\htdocs\emploi\resources\views/partials/_notification-bell.blade.php ENDPATH**/ ?>