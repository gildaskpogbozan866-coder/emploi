﻿
<?php $__env->startSection('title', 'Statistiques | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Statistiques de la plateforme</h1>
    <p>Vue d'ensemble des données clés, Emploi Bouge Bénin</p>
  </div>
</div>


<div class="adm-stats" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));margin-bottom:28px">
  <div class="adm-stat">
    <div class="adm-stat__icon adm-stat__icon--blue">
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
    </div>
    <div>
      <div class="adm-stat__val"><?php echo e($totaux['users']); ?></div>
      <div class="adm-stat__label">Utilisateurs</div>
    </div>
  </div>
  <div class="adm-stat">
    <div class="adm-stat__icon adm-stat__icon--orange">
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2"/></svg>
    </div>
    <div>
      <div class="adm-stat__val"><?php echo e($totaux['offres']); ?></div>
      <div class="adm-stat__label">Offres publiées</div>
    </div>
  </div>
  <div class="adm-stat">
    <div class="adm-stat__icon adm-stat__icon--violet">
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
    </div>
    <div>
      <div class="adm-stat__val"><?php echo e($totaux['candidatures']); ?></div>
      <div class="adm-stat__label">Candidatures</div>
    </div>
  </div>
  <div class="adm-stat">
    <div class="adm-stat__icon adm-stat__icon--yellow">
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg>
    </div>
    <div>
      <div class="adm-stat__val"><?php echo e($totaux['cvs']); ?></div>
      <div class="adm-stat__label">CVs déposés</div>
    </div>
  </div>
  <div class="adm-stat">
    <div class="adm-stat__icon adm-stat__icon--orange">
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/></svg>
    </div>
    <div>
      <div class="adm-stat__val"><?php echo e($totaux['commandes']); ?></div>
      <div class="adm-stat__label">Commandes</div>
    </div>
  </div>
  <div class="adm-stat">
    <div class="adm-stat__icon adm-stat__icon--green">
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
    </div>
    <div>
      <div class="adm-stat__val" style="color:#38A169;font-size:1rem"><?php echo e(number_format($totaux['revenus_30j'],0,',',' ')); ?></div>
      <div class="adm-stat__label">FCFA / 30 jours</div>
    </div>
  </div>
  <div class="adm-stat" style="border:2px solid #e0f2fe">
    <div class="adm-stat__icon" style="background:#e0f2fe">
      <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="#0284c7" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
    </div>
    <div>
      <div class="adm-stat__val" style="color:#0284c7"><?php echo e($tauxConversion); ?>%</div>
      <div class="adm-stat__label">Taux conversion (vues→cand.)</div>
    </div>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

  
  <div class="adm-card" style="grid-column:1/-1">
    <div class="adm-card__header"><h2>Offres par type de contrat</h2></div>
    <div class="adm-card__body">
      <?php $totalOffres = $offresParType->sum('total') ?: 1; ?>
      <?php $__currentLoopData = $offresParType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
          <span style="width:100px;font-size:13px;font-weight:600;color:#475569;flex-shrink:0"><?php echo e($item->type); ?></span>
          <div style="flex:1;height:10px;background:#f1f5f9;border-radius:5px;overflow:hidden">
            <div style="height:100%;background:var(--bleu-clair);border-radius:5px;width:<?php echo e(round($item->total / $totalOffres * 100)); ?>%"></div>
          </div>
          <span style="font-size:13px;font-weight:700;color:#042C53;min-width:30px;text-align:right"><?php echo e($item->total); ?></span>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php if($offresParType->isEmpty()): ?>
        <p style="color:#94a3b8;font-size:13px">Aucune donnée disponible.</p>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="adm-card" style="grid-column:1/-1">
    <div class="adm-card__header"><h2>Offres par statut</h2></div>
    <div class="adm-card__body">
      <?php $__currentLoopData = $offresParStatut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f0f2f5">
          <span class="badge-statut badge-statut--<?php echo e($item->statut); ?>"><?php echo e(ucfirst(str_replace('_',' ',$item->statut))); ?></span>
          <strong><?php echo e($item->total); ?></strong>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php if($offresParStatut->isEmpty()): ?>
        <p style="color:#94a3b8;font-size:13px">Aucune donnée disponible.</p>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="adm-card" style="grid-column:1/-1">
    <div class="adm-card__header"><h2>Candidatures par statut</h2></div>
    <div class="adm-card__body">
      <?php
        $statColors = ['envoyee'=>'#185FA5','retenue'=>'#d97706','acceptee'=>'#16a34a','refusee'=>'#dc2626','en_cours'=>'#7c3aed'];
        $totalCand  = $candidaturesParStatut->sum('total') ?: 1;
      ?>
      <?php $__currentLoopData = $candidaturesParStatut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
          <span style="width:110px;font-size:13px;font-weight:600;color:#475569;flex-shrink:0"><?php echo e(ucfirst(str_replace('_',' ',$item->statut))); ?></span>
          <div style="flex:1;height:10px;background:#f1f5f9;border-radius:5px;overflow:hidden">
            <div style="height:100%;background:<?php echo e($statColors[$item->statut] ?? '#94a3b8'); ?>;border-radius:5px;width:<?php echo e(round($item->total / $totalCand * 100)); ?>%;opacity:.8"></div>
          </div>
          <span style="font-size:13px;font-weight:700;color:#042C53;min-width:30px;text-align:right"><?php echo e($item->total); ?></span>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php if($candidaturesParStatut->isEmpty()): ?>
        <p style="color:#94a3b8;font-size:13px">Aucune donnée disponible.</p>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="adm-card" style="grid-column:1/-1">
    <div class="adm-card__header"><h2>Top 5 offres les plus vues</h2></div>
    <div class="adm-card__body">
      <?php $__currentLoopData = $topOffresVues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="display:flex;align-items:center;gap:12px;padding:10px 0;<?php echo e(!$loop->last ? 'border-bottom:1px solid #f0f2f5;' : ''); ?>">
          <span style="width:22px;height:22px;background:#<?php echo e(['185FA5','378ADD','6AB0F5','042C53','94a3b8'][$i] ?? '94a3b8'); ?>;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0"><?php echo e($i+1); ?></span>
          <div style="flex:1;overflow:hidden">
            <a href="<?php echo e(route('offre.detail', $offre)); ?>" target="_blank" style="font-size:13px;font-weight:600;color:#042C53;text-decoration:none;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo e($offre->titre); ?></a>
            <span style="font-size:12px;color:#64748b"><?php echo e($offre->entreprise); ?></span>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-size:14px;font-weight:700;color:#185FA5"><?php echo e(number_format($offre->vues)); ?></div>
            <div style="font-size:11px;color:#94a3b8">vues</div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php if($topOffresVues->isEmpty()): ?>
        <p style="color:#94a3b8;font-size:13px">Aucune donnée disponible.</p>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="adm-card">
    <div class="adm-card__header"><h2>Nouvelles inscriptions (6 mois)</h2></div>
    <div class="adm-card__body">
      <?php if($inscriptions->isEmpty()): ?>
        <p style="color:#94a3b8;font-size:13px">Aucune inscription sur les 6 derniers mois.</p>
      <?php else: ?>
        <?php $maxIns = $inscriptions->max('total') ?: 1; ?>
        <div style="display:flex;align-items:flex-end;gap:14px;height:110px">
          <?php $__currentLoopData = $inscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
              <span style="font-size:11px;font-weight:700;color:#042C53"><?php echo e($insc->total); ?></span>
              <div style="width:100%;background:#185FA5;border-radius:5px 5px 0 0;height:<?php echo e(round($insc->total / $maxIns * 80)); ?>px;min-height:4px;opacity:.8"></div>
              <span style="font-size:10px;color:#94a3b8"><?php echo e(str_pad($insc->mois,2,'0',STR_PAD_LEFT)); ?>/<?php echo e($insc->annee); ?></span>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="adm-card">
    <div class="adm-card__header"><h2>Candidatures reçues (6 mois)</h2></div>
    <div class="adm-card__body">
      <?php if($candidaturesParMois->isEmpty()): ?>
        <p style="color:#94a3b8;font-size:13px">Aucune candidature sur les 6 derniers mois.</p>
      <?php else: ?>
        <?php $maxCand = $candidaturesParMois->max('total') ?: 1; ?>
        <div style="display:flex;align-items:flex-end;gap:14px;height:110px">
          <?php $__currentLoopData = $candidaturesParMois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
              <span style="font-size:11px;font-weight:700;color:#042C53"><?php echo e($m->total); ?></span>
              <div style="width:100%;background:#16a34a;border-radius:5px 5px 0 0;height:<?php echo e(round($m->total / $maxCand * 80)); ?>px;min-height:4px;opacity:.75"></div>
              <span style="font-size:10px;color:#94a3b8"><?php echo e(str_pad($m->mois,2,'0',STR_PAD_LEFT)); ?>/<?php echo e($m->annee); ?></span>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  
  <div class="adm-card" style="grid-column:1/-1">
    <div class="adm-card__header"><h2>Top recruteurs par candidatures reçues</h2></div>
    <div class="adm-card__body">
      <?php if($topRecruteurs->isEmpty()): ?>
        <p style="color:#94a3b8;font-size:13px">Aucune donnée disponible.</p>
      <?php else: ?>
      <div class="adm-table-wrap">
        <table class="adm-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Recruteur</th>
              <th>Entreprise</th>
              <th>Email</th>
              <th style="text-align:right">Candidatures reçues</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $topRecruteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td style="font-weight:700;color:#185FA5"><?php echo e($i + 1); ?></td>
              <td><?php echo e($rec->nom_complet); ?></td>
              <td><?php echo e($rec->entreprise ?? '-'); ?></td>
              <td style="font-size:12.5px;color:#64748b"><?php echo e($rec->email); ?></td>
              <td style="text-align:right;font-weight:700;color:#042C53"><?php echo e($rec->total_candidatures); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/statistiques.blade.php ENDPATH**/ ?>