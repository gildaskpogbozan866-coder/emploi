
<?php $hasActive = collect($filters ?? [])->filter(fn($f) => request()->filled($f['name']))->isNotEmpty() || request()->filled('q'); ?>
<form method="GET" action="<?php echo e(route($route)); ?>"
      style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px;align-items:center">
  <?php if($searchable ?? true): ?>
  <input type="text" name="q" value="<?php echo e(request('q')); ?>"
         placeholder="<?php echo e($placeholder ?? 'Rechercher…'); ?>"
         style="flex:1;min-width:180px;padding:8px 12px;border:1.5px solid #d1d5db;border-radius:8px;font-size:13px">
  <?php endif; ?>

  <?php $__currentLoopData = $filters ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(isset($filter['options'])): ?>
    <select name="<?php echo e($filter['name']); ?>"
            style="padding:8px 10px;border:1.5px solid #d1d5db;border-radius:8px;font-size:13px;background:#fff">
      <option value=""><?php echo e($filter['label'] ?? 'Tous'); ?></option>
      <?php $__currentLoopData = $filter['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($val); ?>" <?php echo e(request($filter['name']) === (string)$val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <button type="submit"
          style="padding:8px 16px;background:#185FA5;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;white-space:nowrap">
    Filtrer
  </button>
  <?php if($hasActive): ?>
    <a href="<?php echo e(route($route)); ?>"
       style="padding:8px 12px;border:1.5px solid #d1d5db;border-radius:8px;font-size:13px;color:#64748b;text-decoration:none;white-space:nowrap">
      ✕ Réinitialiser
    </a>
  <?php endif; ?>
</form>
<?php /**PATH C:\xampp\htdocs\emploi\resources\views/partials/_search-bar.blade.php ENDPATH**/ ?>