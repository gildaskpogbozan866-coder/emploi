﻿
<?php $__env->startSection('title', 'Candidats | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Candidats inscrits</h1>
    <p><?php echo e($candidats->total()); ?> candidat<?php echo e($candidats->total() > 1 ? 's' : ''); ?> enregistré<?php echo e($candidats->total() > 1 ? 's' : ''); ?> sur la plateforme</p>
  </div>
</div>

<div class="adm-filters">
  <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;width:100%">
    <div class="adm-search" style="flex:1;max-width:340px">
      <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Rechercher par nom, email…">
    </div>
    <button type="submit" class="adm-btn adm-btn--primary">Rechercher</button>
    <?php if(request('q')): ?>
      <a href="<?php echo e(route('admin.utilisateurs.candidats')); ?>" class="adm-btn adm-btn--outline">Effacer</a>
    <?php endif; ?>
  </form>
</div>

<div class="adm-card">
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>Nom</th><th>Email</th><th>Pays</th><th>CVs</th><th>Statut</th><th>Inscrit le</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $candidats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div class="adm-avatar"><?php echo e(strtoupper(substr($user->prenom ?? '?', 0, 1))); ?></div>
              <div>
                <a href="<?php echo e(route('admin.utilisateurs.candidats.detail', $user)); ?>" style="font-weight:600;color:#042C53;text-decoration:none"><?php echo e($user->nom_complet); ?></a>
              </div>
            </div>
          </td>
          <td style="color:#64748b;font-size:12.5px"><?php echo e($user->email); ?></td>
          <td style="color:#64748b"><?php echo e($user->pays ?? '-'); ?></td>
          <td><strong><?php echo e($user->cvs->count()); ?></strong></td>
          <td>
            <span class="adm-badge adm-badge--<?php echo e($user->actif ? 'green' : 'red'); ?>">
              <?php echo e($user->actif ? 'Actif' : 'Suspendu'); ?>

            </span>
          </td>
          <td style="color:#94a3b8;font-size:12px"><?php echo e($user->created_at->format('d/m/Y')); ?></td>
          <td>
            <div class="actions">
              <form method="POST" action="<?php echo e(route('admin.utilisateurs.statut', $user)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button type="submit" class="adm-btn <?php echo e($user->actif ? 'adm-btn--danger' : 'adm-btn--green'); ?> adm-btn--sm">
                  <?php echo e($user->actif ? 'Suspendre' : 'Réactiver'); ?>

                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="7">
            <div class="adm-empty">
              <svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
              <h3>Aucun candidat trouvé</h3>
              <p>Essayez d'ajuster vos critères de recherche.</p>
            </div>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($candidats->hasPages()): ?>
    <div style="padding:16px 22px"><?php echo e($candidats->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/utilisateurs/candidats.blade.php ENDPATH**/ ?>