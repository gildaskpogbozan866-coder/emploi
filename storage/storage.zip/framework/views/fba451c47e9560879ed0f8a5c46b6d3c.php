﻿
<?php $__env->startSection('title', 'Recruteurs | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Recruteurs inscrits</h1>
    <p><?php echo e($recruteurs->total()); ?> recruteur<?php echo e($recruteurs->total() > 1 ? 's' : ''); ?> enregistré<?php echo e($recruteurs->total() > 1 ? 's' : ''); ?></p>
  </div>
</div>

<div class="adm-filters">
  <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;width:100%">
    <div class="adm-search" style="flex:1;max-width:340px">
      <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Nom, entreprise, email…">
    </div>
    <button type="submit" class="adm-btn adm-btn--primary">Rechercher</button>
    <?php if(request('q')): ?>
      <a href="<?php echo e(route('admin.utilisateurs.recruteurs')); ?>" class="adm-btn adm-btn--outline">Effacer</a>
    <?php endif; ?>
  </form>
</div>

<div class="adm-card">
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>Recruteur</th><th>Entreprise</th><th>Email</th><th>Offres</th><th>Abonnement</th><th>Statut</th><th>Inscrit le</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $recruteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div class="adm-avatar"><?php echo e(strtoupper(substr($user->prenom ?? '?', 0, 1))); ?></div>
              <a href="<?php echo e(route('admin.utilisateurs.recruteurs.detail', $user)); ?>" style="font-weight:600;color:#042C53;text-decoration:none"><?php echo e($user->nom_complet); ?></a>
            </div>
          </td>
          <td style="color:#64748b"><?php echo e($user->entreprise ?? '-'); ?></td>
          <td style="color:#64748b;font-size:12.5px"><?php echo e($user->email); ?></td>
          <td><strong><?php echo e($user->offres_count); ?></strong></td>
          <td>
            <?php if($user->premium): ?>
              <span class="adm-badge adm-badge--yellow">★ Premium</span>
            <?php else: ?>
              <span style="color:#94a3b8;font-size:12px">Gratuit</span>
            <?php endif; ?>
          </td>
          <td>
            <span class="adm-badge adm-badge--<?php echo e($user->actif ? 'green' : 'red'); ?>">
              <?php echo e($user->actif ? 'Actif' : 'Suspendu'); ?>

            </span>
          </td>
          <td style="color:#94a3b8;font-size:12px"><?php echo e($user->created_at->format('d/m/Y')); ?></td>
          <td>
            <div class="actions">
              <form method="POST" action="<?php echo e(route('admin.utilisateurs.statut', $user)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button type="submit" class="adm-btn <?php echo e($user->actif ? 'adm-btn--danger' : 'adm-btn--green'); ?> adm-btn--sm">
                  <?php echo e($user->actif ? 'Suspendre' : 'Réactiver'); ?>

                </button>
              </form>
              <form method="POST" action="<?php echo e(route('admin.utilisateurs.destroy', $user)); ?>"
                    data-confirm="Supprimer définitivement le compte de <?php echo e($user->nom_complet); ?> ? Cette action est irréversible."
                    data-confirm-btn="Supprimer">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="adm-btn adm-btn--danger adm-btn--sm">Supprimer</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="8">
            <div class="adm-empty">
              <svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
              <h3>Aucun recruteur trouvé</h3>
              <p>Essayez d'ajuster vos critères de recherche.</p>
            </div>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($recruteurs->hasPages()): ?>
    <div style="padding:16px 22px"><?php echo e($recruteurs->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/utilisateurs/recruteurs.blade.php ENDPATH**/ ?>