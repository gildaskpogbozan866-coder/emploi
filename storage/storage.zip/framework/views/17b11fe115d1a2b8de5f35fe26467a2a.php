﻿
<?php $__env->startSection('title', 'CVs & Documents | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>CVs & Documents</h1>
    <p><?php echo e($items->total()); ?> <?php echo e($type === 'documents' ? 'document' : 'CV'); ?><?php echo e($items->total() > 1 ? 's' : ''); ?> déposé<?php echo e($items->total() > 1 ? 's' : ''); ?></p>
  </div>
</div>


<div style="display:flex;gap:4px;margin-bottom:18px;border-bottom:2px solid #e2e8f0">
  <a href="<?php echo e(route('admin.cvs.list', ['type'=>'cvs'] + request()->except('type','page'))); ?>"
     style="padding:8px 20px;font-size:13.5px;font-weight:600;border-radius:6px 6px 0 0;border:2px solid transparent;border-bottom:none;text-decoration:none;
            <?php echo e($type === 'cvs' ? 'background:#fff;border-color:#e2e8f0;color:#042C53;margin-bottom:-2px' : 'color:#64748b'); ?>">
    CVs
  </a>
  <a href="<?php echo e(route('admin.cvs.list', ['type'=>'documents'] + request()->except('type','page'))); ?>"
     style="padding:8px 20px;font-size:13.5px;font-weight:600;border-radius:6px 6px 0 0;border:2px solid transparent;border-bottom:none;text-decoration:none;
            <?php echo e($type === 'documents' ? 'background:#fff;border-color:#e2e8f0;color:#042C53;margin-bottom:-2px' : 'color:#64748b'); ?>">
    Documents
  </a>
</div>


<div class="adm-filters">
  <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;width:100%">
    <input type="hidden" name="type" value="<?php echo e($type); ?>">
    <div class="adm-search" style="flex:1;max-width:320px">
      <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="<?php echo e($type === 'documents' ? 'Nom, candidat, pays…' : 'Titre de poste, pays…'); ?>">
    </div>

    <?php if($type === 'cvs'): ?>
      <select name="plan" class="adm-select">
        <option value="">Tous les plans</option>
        <option value="gratuit" <?php echo e(request('plan') === 'gratuit' ? 'selected' : ''); ?>>Gratuit</option>
        <option value="premium" <?php echo e(request('plan') === 'premium' ? 'selected' : ''); ?>>Premium</option>
      </select>
    <?php else: ?>
      <select name="type_doc" class="adm-select">
        <option value="">Tous les types</option>
        <?php $__currentLoopData = $typeDocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($td->id); ?>" <?php echo e(request('type_doc') == $td->id ? 'selected' : ''); ?>><?php echo e($td->nom); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    <?php endif; ?>

    <button type="submit" class="adm-btn adm-btn--primary">Filtrer</button>
    <?php if(request()->hasAny(['q','plan','type_doc'])): ?>
      <a href="<?php echo e(route('admin.cvs.list', ['type'=>$type])); ?>" class="adm-btn adm-btn--outline">Effacer</a>
    <?php endif; ?>
  </form>
</div>

<div class="adm-card">
  <div class="adm-table-wrap">

    <?php if($type === 'cvs'): ?>
    <table class="adm-table">
      <thead>
        <tr><th>Candidat</th><th>Poste visé</th><th>Pays</th><th>Plan</th><th>Vues</th><th>Visible</th><th>Déposé le</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td>
            <div style="font-weight:600;color:#042C53"><?php echo e($cv->candidat->nom_complet); ?></div>
            <div style="font-size:12px;color:#94a3b8"><?php echo e($cv->candidat->email); ?></div>
          </td>
          <td style="font-weight:500;color:#042C53"><?php echo e($cv->titre_poste); ?></td>
          <td style="color:#64748b"><?php echo e($cv->pays); ?></td>
          <td>
            <span class="adm-badge adm-badge--<?php echo e($cv->plan === 'premium' ? 'yellow' : 'gray'); ?>"><?php echo e(ucfirst($cv->plan)); ?></span>
          </td>
          <td style="text-align:center"><strong><?php echo e($cv->vues); ?></strong></td>
          <td style="text-align:center">
            <span class="adm-badge adm-badge--<?php echo e($cv->visible ? 'green' : 'red'); ?>"><?php echo e($cv->visible ? 'Oui' : 'Non'); ?></span>
          </td>
          <td style="color:#94a3b8;font-size:12px"><?php echo e($cv->created_at->format('d/m/Y')); ?></td>
          <td>
            <div class="actions">
              <a href="<?php echo e(route('admin.cvs.detail', $cv)); ?>" class="adm-btn adm-btn--outline adm-btn--sm">Voir</a>
              <form method="POST" action="<?php echo e(route('admin.cvs.destroy', $cv)); ?>" data-confirm="Supprimer ce CV ?" data-confirm-btn="Supprimer">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="adm-btn adm-btn--danger adm-btn--sm">Supprimer</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8"><div class="adm-empty"><svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg><h3>Aucun CV trouvé</h3></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <?php else: ?>
    <table class="adm-table">
      <thead>
        <tr><th>Candidat</th><th>Nom du document</th><th>Type</th><th>Pays</th><th>Déposé le</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td>
            <div style="font-weight:600;color:#042C53"><?php echo e($doc->user->nom_complet); ?></div>
            <div style="font-size:12px;color:#94a3b8"><?php echo e($doc->user->email); ?></div>
          </td>
          <td style="font-weight:500;color:#042C53"><?php echo e($doc->nom); ?></td>
          <td><span class="adm-badge adm-badge--blue"><?php echo e($doc->type->nom ?? '-'); ?></span></td>
          <td style="color:#64748b"><?php echo e($doc->pays ?? '-'); ?></td>
          <td style="color:#94a3b8;font-size:12px"><?php echo e($doc->created_at->format('d/m/Y')); ?></td>
          <td>
            <div class="actions">
              <a href="<?php echo e(route('admin.documents.detail', $doc)); ?>" class="adm-btn adm-btn--outline adm-btn--sm">Voir</a>
              <form method="POST" action="<?php echo e(route('admin.documents.destroy', $doc)); ?>" data-confirm="Supprimer ce document ?" data-confirm-btn="Supprimer">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="adm-btn adm-btn--danger adm-btn--sm">Supprimer</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6"><div class="adm-empty"><svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg><h3>Aucun document trouvé</h3></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
    <?php endif; ?>

  </div>
  <?php if($items->hasPages()): ?>
    <div style="padding:16px 22px"><?php echo e($items->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/cvs/list.blade.php ENDPATH**/ ?>