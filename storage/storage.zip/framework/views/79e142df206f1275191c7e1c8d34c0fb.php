﻿
<?php $__env->startSection('title', 'Publicités | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Publicités</h1>
    <p>Modérez les annonces soumises par les annonceurs.</p>
  </div>
</div>


<div style="display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap">
  <?php $__currentLoopData = [
    ['label' => 'En attente', 'value' => $counts['en_attente'], 'color' => '#d97706', 'bg' => '#fef3c7', 'statut' => 'en_attente'],
    ['label' => 'Approuvées', 'value' => $counts['approuve'],   'color' => '#16a34a', 'bg' => '#dcfce7', 'statut' => 'approuve'],
    ['label' => 'Rejetées',   'value' => $counts['rejete'],     'color' => '#dc2626', 'bg' => '#fee2e2', 'statut' => 'rejete'],
  ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo e(request()->fullUrlWithQuery(['statut' => $c['statut']])); ?>"
     style="display:flex;align-items:center;gap:10px;padding:12px 18px;background:<?php echo e($c['bg']); ?>;border-radius:10px;text-decoration:none;flex:1;min-width:140px">
    <span style="font-size:1.5rem;font-weight:800;color:<?php echo e($c['color']); ?>"><?php echo e($c['value']); ?></span>
    <span style="font-size:13px;font-weight:600;color:<?php echo e($c['color']); ?>"><?php echo e($c['label']); ?></span>
  </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="adm-card">
  <div class="adm-card__body" style="padding:0">
    <?php if($publicites->isEmpty()): ?>
      <div class="adm-empty" style="padding:48px 20px">
        <svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
        <h3>Aucune publicité</h3>
        <p>Aucune annonce ne correspond aux filtres sélectionnés.</p>
        <a href="<?php echo e(route('admin.publicites.index')); ?>" class="adm-btn adm-btn--outline adm-btn--sm">Voir tout</a>
      </div>
    <?php else: ?>
      <table class="adm-table">
        <thead>
          <tr>
            <th>Annonce</th>
            <th>Annonceur</th>
            <th>Statut</th>
            <th>Diffusion</th>
            <th>Soumise le</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $publicites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <div style="display:flex;align-items:center;gap:12px">
                <img src="<?php echo e(asset('storage/' . $pub->image)); ?>"
                     alt="<?php echo e($pub->titre); ?>"
                     style="width:64px;height:48px;object-fit:cover;border-radius:6px;flex-shrink:0">
                <div>
                  <div style="font-weight:600;color:#042C53;font-size:13.5px"><?php echo e($pub->titre); ?></div>
                  <?php if($pub->lien): ?>
                    <div style="font-size:12px;color:#94a3b8"><?php echo e(Str::limit($pub->lien, 35)); ?></div>
                  <?php endif; ?>
                </div>
              </div>
            </td>
            <td>
              <div style="font-weight:600;color:#042C53;font-size:13px"><?php echo e($pub->user->nom_complet); ?></div>
              <div style="font-size:12px;color:#94a3b8"><?php echo e($pub->user->email); ?></div>
            </td>
            <td>
              <span class="adm-badge adm-badge--<?php echo e($pub->statut_badge); ?>"><?php echo e($pub->statut_label); ?></span>
            </td>
            <td style="font-size:12.5px;color:#64748b">
              <?php if($pub->date_debut || $pub->date_fin): ?>
                <?php echo e($pub->date_debut?->format('d/m/Y') ?? '-'); ?>→<?php echo e($pub->date_fin?->format('d/m/Y') ?? '∞'); ?>

              <?php else: ?>
                <span style="color:#94a3b8">Sans limite</span>
              <?php endif; ?>
            </td>
            <td style="font-size:13px;color:#64748b;white-space:nowrap"><?php echo e($pub->created_at->format('d/m/Y')); ?></td>
            <td>
              <a href="<?php echo e(route('admin.publicites.show', $pub)); ?>" class="adm-btn adm-btn--outline adm-btn--sm">Examiner</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div style="padding:16px 24px">
        <?php echo e($publicites->links()); ?>

      </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/publicites/index.blade.php ENDPATH**/ ?>