<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $__env->yieldContent('title', 'Emploi Bouge Bénin'); ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600&family=Jost:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
  <link rel="icon" type="image/png" sizes="64x64" href="<?php echo e(asset('images/favicon-64.png')); ?>?v=2">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/favicon-32.png')); ?>?v=2">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon-16.png')); ?>?v=2">
  <link rel="shortcut icon" href="<?php echo e(asset('images/favicon-64.png')); ?>?v=2">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
  <?php echo $__env->yieldContent('css'); ?>
  <style>body { padding-top: 0 !important; }</style>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <?php echo $__env->make('partials._pwa-head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>

  <?php echo $__env->yieldContent('content'); ?>

  <?php echo $__env->make('partials._form-guard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php echo $__env->yieldContent('scripts'); ?>
  <?php echo $__env->make('partials._pwa-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\emploi\resources\views/layouts/auth.blade.php ENDPATH**/ ?>