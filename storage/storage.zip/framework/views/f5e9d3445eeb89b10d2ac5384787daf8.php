
<link rel="manifest" href="<?php echo e(route('pwa.manifest')); ?>">
<meta name="theme-color" content="#042C53">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Emploi Bénin">
<link rel="apple-touch-icon" href="<?php echo e(asset('images/pwa-icon-192.png')); ?>">
<?php /**PATH C:\xampp\htdocs\emploi\resources\views/partials/_pwa-head.blade.php ENDPATH**/ ?>