﻿
<?php $__env->startSection('title', 'Offres | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Gestion des offres</h1>
    <p><?php echo e($offres->total()); ?> offre<?php echo e($offres->total() > 1 ? 's' : ''); ?> au total</p>
  </div>
</div>

<div class="adm-filters">
  <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;width:100%">
    <div class="adm-search" style="flex:1;max-width:300px">
      <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Titre, entreprise…">
    </div>
    <select name="statut" class="adm-select">
      <option value="">Tous les statuts</option>
      <?php $__currentLoopData = ['en_attente' => 'En attente','active' => 'Active','expiree' => 'Expirée','suspendue' => 'Suspendue']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($val); ?>" <?php echo e(request('statut') === $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button type="submit" class="adm-btn adm-btn--primary">Filtrer</button>
    <?php if(request()->hasAny(['q','statut'])): ?>
      <a href="<?php echo e(route('admin.offres.list')); ?>" class="adm-btn adm-btn--outline">Effacer</a>
    <?php endif; ?>
  </form>
</div>

<div class="adm-card">
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>Titre</th><th>Entreprise</th><th>Type</th><th>Candidatures</th><th>Statut</th><th>Date</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td style="max-width:200px">
            <p style="font-weight:500;margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo e($offre->titre); ?></p>
          </td>
          <td style="color:#64748b"><?php echo e($offre->entreprise); ?></td>
          <td><span class="tag tag--type"><?php echo e($offre->type); ?></span></td>
          <td><strong><?php echo e($offre->candidatures_count); ?></strong></td>
          <td>
            <form method="POST" action="<?php echo e(route('admin.offres.statut', $offre)); ?>">
              <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
              <select name="statut" onchange="this.form.submit()" class="adm-select" style="padding:5px 8px;font-size:12px">
                <?php $__currentLoopData = ['en_attente' => 'En attente','active' => 'Active','expiree' => 'Expirée','suspendue' => 'Suspendue']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($val); ?>" <?php echo e($offre->statut === $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </form>
          </td>
          <td style="color:#94a3b8;font-size:12px"><?php echo e($offre->created_at->format('d/m/Y')); ?></td>
          <td>
            <div class="actions">
              <a href="<?php echo e(route('offre.detail', $offre)); ?>" target="_blank" class="adm-btn adm-btn--outline adm-btn--sm">Voir</a>
              <form method="POST" action="<?php echo e(route('admin.offres.destroy', $offre)); ?>" data-confirm="Supprimer cette offre ?" data-confirm-btn="Supprimer">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="adm-btn adm-btn--danger adm-btn--sm">Supprimer</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="7">
            <div class="adm-empty">
              <svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2"/></svg>
              <h3>Aucune offre trouvée</h3>
              <p>Essayez d'ajuster vos critères.</p>
            </div>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($offres->hasPages()): ?>
    <div style="padding:16px 22px"><?php echo e($offres->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/offres/list.blade.php ENDPATH**/ ?>