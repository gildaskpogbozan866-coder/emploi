﻿
<?php $__env->startSection('title', 'Tous les utilisateurs | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Tous les utilisateurs</h1>
    <p><?php echo e($users->total()); ?> utilisateur<?php echo e($users->total() > 1 ? 's' : ''); ?> enregistré<?php echo e($users->total() > 1 ? 's' : ''); ?></p>
  </div>
  <div style="display:flex;gap:10px">
    <a href="<?php echo e(route('admin.utilisateurs.candidats')); ?>" class="adm-btn adm-btn--outline">Candidats</a>
    <a href="<?php echo e(route('admin.utilisateurs.recruteurs')); ?>" class="adm-btn adm-btn--outline">Recruteurs</a>
  </div>
</div>

<div class="adm-card">
  <div style="padding:16px 22px 0">
    <?php echo $__env->make('partials._search-bar', [
      'route'       => 'admin.utilisateurs.list',
      'placeholder' => 'Nom, prénom ou email…',
      'filters'     => [
        ['name' => 'role',   'label' => 'Tous les rôles',   'options' => ['candidat' => 'Candidat', 'recruteur' => 'Recruteur', 'admin' => 'Admin']],
        ['name' => 'statut', 'label' => 'Tous les statuts', 'options' => ['actif' => 'Actif', 'suspendu' => 'Suspendu']],
      ],
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>Nom</th><th>Email</th><th>Rôle</th><th>Premium</th><th>Statut</th><th>Inscription</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div class="adm-avatar"><?php echo e(strtoupper(substr($user->prenom ?? '?', 0, 1))); ?></div>
              <span style="font-weight:600;color:#042C53"><?php echo e($user->nom_complet); ?></span>
            </div>
          </td>
          <td style="color:#64748b;font-size:12.5px"><?php echo e($user->email); ?></td>
          <td>
            <span class="adm-badge adm-badge--<?php echo e(match($user->role) {
              'admin'     => 'red',
              'recruteur' => 'violet',
              default     => 'blue'
            }); ?>"><?php echo e(ucfirst($user->role)); ?></span>
          </td>
          <td>
            <?php if($user->premium): ?>
              <span class="adm-badge adm-badge--yellow">★ Premium</span>
            <?php else: ?>
              <span style="color:#94a3b8;font-size:12px">Gratuit</span>
            <?php endif; ?>
          </td>
          <td>
            <span class="adm-badge adm-badge--<?php echo e($user->actif ? 'green' : 'red'); ?>">
              <?php echo e($user->actif ? 'Actif' : 'Suspendu'); ?>

            </span>
          </td>
          <td style="color:#94a3b8;font-size:12px"><?php echo e($user->created_at->format('d/m/Y')); ?></td>
          <td>
            <div class="actions">
              <?php if($user->role !== 'admin'): ?>
              <form method="POST" action="<?php echo e(route('admin.utilisateurs.statut', $user)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <button type="submit" class="adm-btn <?php echo e($user->actif ? 'adm-btn--danger' : 'adm-btn--green'); ?> adm-btn--sm">
                  <?php echo e($user->actif ? 'Suspendre' : 'Réactiver'); ?>

                </button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="7">
            <div class="adm-empty">
              <svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
              <h3>Aucun utilisateur</h3>
            </div>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($users->hasPages()): ?>
    <div style="padding:16px 22px"><?php echo e($users->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/utilisateurs/list.blade.php ENDPATH**/ ?>