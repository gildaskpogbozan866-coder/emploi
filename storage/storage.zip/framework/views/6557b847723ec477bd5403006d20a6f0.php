<?php $__env->startSection('title', 'Packs Crédits CVthèque — Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Packs Crédits CVthèque</h1>
    <p><?php echo e($packs->count()); ?> pack<?php echo e($packs->count() > 1 ? 's' : ''); ?> configuré<?php echo e($packs->count() > 1 ? 's' : ''); ?></p>
  </div>
  <a href="<?php echo e(route('admin.credit-cv-packs.create')); ?>" class="adm-btn adm-btn--yellow">
    <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Nouveau pack
  </a>
</div>

<?php if(session('success')): ?>
  <div class="adm-alert adm-alert--success" style="margin-bottom:16px"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="adm-alert adm-alert--danger" style="margin-bottom:16px"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="adm-card">
  <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:13.5px">
      <thead>
        <tr style="background:#f8fafc">
          <th style="padding:11px 18px;text-align:left;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Ordre</th>
          <th style="padding:11px 18px;text-align:left;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Label</th>
          <th style="padding:11px 18px;text-align:left;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Crédits</th>
          <th style="padding:11px 18px;text-align:left;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Prix (FCFA)</th>
          <th style="padding:11px 18px;text-align:left;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Prix / crédit</th>
          <th style="padding:11px 18px;text-align:left;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Badge</th>
          <th style="padding:11px 18px;text-align:left;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Vedette</th>
          <th style="padding:11px 18px;text-align:left;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Statut</th>
          <th style="padding:11px 18px;text-align:right;font-size:11.5px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr style="border-bottom:1px solid #f1f5f9;<?php echo e(!$pack->actif ? 'opacity:.55' : ''); ?>">
          <td style="padding:12px 18px;color:#94a3b8;font-size:13px"><?php echo e($pack->ordre); ?></td>
          <td style="padding:12px 18px;font-weight:700;color:#042C53"><?php echo e($pack->label); ?></td>
          <td style="padding:12px 18px">
            <span style="font-size:1.2rem;font-weight:900;color:#042C53"><?php echo e($pack->credits); ?></span>
          </td>
          <td style="padding:12px 18px;font-weight:700;color:#185FA5"><?php echo e(number_format($pack->prix, 0, ',', ' ')); ?></td>
          <td style="padding:12px 18px;font-size:12px;color:#64748b"><?php echo e(number_format($pack->prixParCredit(), 0, ',', ' ')); ?> / CV</td>
          <td style="padding:12px 18px">
            <?php if($pack->badge): ?>
              <span style="background:#fef3c7;color:#92400e;font-size:11px;font-weight:700;padding:2px 10px;border-radius:20px"><?php echo e($pack->badge); ?></span>
            <?php else: ?>
              <span style="color:#d1d5db">—</span>
            <?php endif; ?>
          </td>
          <td style="padding:12px 18px">
            <?php if($pack->featured): ?>
              <span style="background:#042C53;color:#F5C842;font-size:11px;font-weight:700;padding:2px 10px;border-radius:20px">Vedette</span>
            <?php else: ?>
              <span style="color:#d1d5db">—</span>
            <?php endif; ?>
          </td>
          <td style="padding:12px 18px">
            <form method="POST" action="<?php echo e(route('admin.credit-cv-packs.toggle', $pack)); ?>" style="display:inline">
              <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
              <button type="submit" style="border:none;background:none;cursor:pointer;padding:0">
                <?php if($pack->actif): ?>
                  <span class="adm-badge adm-badge--green">Actif</span>
                <?php else: ?>
                  <span class="adm-badge adm-badge--gray">Inactif</span>
                <?php endif; ?>
              </button>
            </form>
          </td>
          <td style="padding:12px 18px;text-align:right;white-space:nowrap">
            <a href="<?php echo e(route('admin.credit-cv-packs.edit', $pack)); ?>" class="adm-btn adm-btn--sm adm-btn--outline" style="margin-right:6px">Modifier</a>
            <form method="POST" action="<?php echo e(route('admin.credit-cv-packs.destroy', $pack)); ?>" style="display:inline"
                  onsubmit="return confirm('Supprimer le pack « <?php echo e($pack->label); ?> » ?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button type="submit" class="adm-btn adm-btn--sm adm-btn--danger">Supprimer</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="9" style="padding:40px;text-align:center;color:#94a3b8">Aucun pack configuré.</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/credit-cv-packs/index.blade.php ENDPATH**/ ?>