﻿
<?php $__env->startSection('title', 'Page introuvable | Emploi Bouge Bénin'); ?>

<?php $__env->startSection('content'); ?>
<section class="error-page">
  <div class="error-page__inner">
    <div class="error-page__code">404</div>
    <h1 class="error-page__title">Page introuvable</h1>
    <p class="error-page__desc">La page que vous cherchez n'existe plus ou a été déplacée.</p>
    <div class="error-page__actions">
      <a href="<?php echo e(route('home')); ?>" class="btn btn--yellow">Retour à l'accueil</a>
      <a href="<?php echo e(route('offre.list')); ?>" class="btn btn--outline">Voir les offres</a>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/errors/404.blade.php ENDPATH**/ ?>