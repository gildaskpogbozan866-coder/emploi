﻿
<?php $__env->startSection('title', 'Commandes | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Commandes de services</h1>
    <p><?php echo e($commandes->total()); ?> commande<?php echo e($commandes->total() > 1 ? 's' : ''); ?> au total</p>
  </div>
</div>

<div class="adm-filters" style="margin-bottom:16px">
  <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;width:100%;align-items:center">
    <div class="adm-search" style="flex:1;max-width:320px">
      <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Référence, client, email…">
    </div>
    <select name="statut" class="adm-select">
      <option value="">Tous les statuts</option>
      <?php $__currentLoopData = ['en_attente' => 'En attente','en_cours' => 'En cours','livree' => 'Livrée','annulee' => 'Annulée']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($val); ?>" <?php echo e(request('statut') === $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button type="submit" class="adm-btn adm-btn--primary">Filtrer</button>
    <?php if(request()->hasAny(['q', 'statut'])): ?>
      <a href="<?php echo e(route('admin.commandes.list')); ?>" class="adm-btn adm-btn--outline">Effacer</a>
    <?php endif; ?>
  </form>
</div>

<div class="adm-card">
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>Référence</th><th>Client</th><th>Service</th><th>Montant</th><th>Statut</th><th>Paiement</th><th>Date</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td style="font-family:monospace;font-size:12px;color:#64748b"><?php echo e($commande->reference); ?></td>
          <td>
            <div style="font-weight:600;color:#042C53"><?php echo e($commande->user?->nom_complet ?? 'Invité'); ?></div>
            <div style="font-size:12px;color:#94a3b8"><?php echo e($commande->user?->email ?? $commande->email_contact ?? '—'); ?></div>
          </td>
          <td style="font-weight:500;color:#042C53"><?php echo e($commande->service->nom); ?></td>
          <td style="font-weight:700;color:#185FA5"><?php echo e(number_format($commande->montant, 0, ',', ' ')); ?> FCFA</td>
          <td>
            <form method="POST" action="<?php echo e(route('admin.commandes.statut', $commande)); ?>" style="margin:0">
              <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
              <select name="statut" onchange="this.form.submit()" class="adm-select" style="padding:5px 8px;font-size:12px">
                <?php $__currentLoopData = ['en_attente' => 'En attente','en_cours' => 'En cours','livree' => 'Livrée','annulee' => 'Annulée']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($val); ?>" <?php echo e($commande->statut === $val ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </form>
          </td>
          <td>
            <span class="adm-badge adm-badge--<?php echo e(match($commande->paiement_statut ?? 'non_paye') {
              'paye'      => 'green',
              'non_paye'  => 'gray',
              default     => 'gray'
            }); ?>">
              <?php echo e($commande->paiement_statut === 'paye' ? 'Payé' : 'Non payé'); ?>

            </span>
          </td>
          <td style="color:#94a3b8;font-size:12px"><?php echo e($commande->created_at->format('d/m/Y')); ?></td>
          <td>
            <a href="<?php echo e(route('admin.commandes.detail', $commande)); ?>" class="adm-btn adm-btn--outline adm-btn--sm">Voir</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="8">
            <div class="adm-empty">
              <svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
              <h3>Aucune commande</h3>
            </div>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($commandes->hasPages()): ?>
    <div style="padding:16px 22px"><?php echo e($commandes->links()); ?></div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/services/commandes.blade.php ENDPATH**/ ?>