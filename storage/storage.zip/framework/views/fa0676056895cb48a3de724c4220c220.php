﻿
<?php $__env->startSection('title', 'Plans d\'abonnement, Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Plans d'abonnement</h1>
    <p><?php echo e($plans->count()); ?> plan<?php echo e($plans->count() > 1 ? 's' : ''); ?> configuré<?php echo e($plans->count() > 1 ? 's' : ''); ?></p>
  </div>
  <a href="<?php echo e(route('admin.plans.create')); ?>" class="adm-btn adm-btn--yellow">
    <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Nouveau plan
  </a>
</div>

<?php if(session('success')): ?>
  <div class="adm-alert adm-alert--success" style="margin-bottom:16px"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="adm-alert adm-alert--danger" style="margin-bottom:16px"><?php echo e(session('error')); ?></div>
<?php endif; ?>


<?php $__currentLoopData = ['candidat' => 'Candidats', 'recruteur' => 'Recruteurs', 'both' => 'Tous (candidats & recruteurs)']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php $group = $plans->where('target_type', $type) ?>
  <?php if($group->count()): ?>
  <div style="margin-bottom:32px">
    <h3 style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#64748b;margin:0 0 12px">
      <?php echo e($label); ?>

    </h3>
    <div class="adm-card">
      <div class="adm-table-wrap">
        <table class="adm-table">
          <thead>
            <tr>
              <th>Plan</th>
              <th>Prix / Durée</th>
              <th>Fonctionnalités</th>
              <th style="text-align:center">Abonnements</th>
              <th style="text-align:center">Statut</th>
              <th style="text-align:right">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
              <td>
                <div style="font-weight:600;color:#042C53"><?php echo e($plan->name); ?></div>
                <div style="font-size:11.5px;color:#94a3b8;font-family:monospace"><?php echo e($plan->slug); ?></div>
                <?php if($plan->description): ?>
                  <div style="font-size:12px;color:#64748b;margin-top:2px"><?php echo e(Str::limit($plan->description, 70)); ?></div>
                <?php endif; ?>
              </td>

              
              <td>
                <?php if($plan->is_free): ?>
                  <span class="adm-badge adm-badge--green">Gratuit</span>
                <?php else: ?>
                  <div style="font-weight:700;color:#185FA5"><?php echo e(number_format($plan->price, 0, ',', ' ')); ?> <?php echo e($plan->currency); ?></div>
                <?php endif; ?>
                <div style="font-size:12px;color:#64748b;margin-top:3px">
                  <?php echo e($plan->duration_days ? $plan->duration_days . ' jours' : 'Illimité'); ?>

                </div>
              </td>

              
              <td>
                <?php if($plan->features->isEmpty()): ?>
                  <span style="color:#cbd5e1;font-size:12px">-</span>
                <?php else: ?>
                  <div style="display:flex;flex-wrap:wrap;gap:4px">
                    <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <span style="background:#f1f5f9;color:#334155;font-size:11.5px;padding:2px 7px;border-radius:99px;white-space:nowrap">
                        <?php echo e($f->feature_key); ?> : <?php echo e($f->feature_value); ?>

                      </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                <?php endif; ?>
              </td>

              
              <td style="text-align:center">
                <div style="font-weight:700;font-size:15px;color:#042C53"><?php echo e($plan->abonnements_actifs_count); ?></div>
                <div style="font-size:11px;color:#94a3b8">actifs / <?php echo e($plan->abonnements_count); ?> total</div>
              </td>

              
              <td style="text-align:center">
                <span class="adm-badge adm-badge--<?php echo e($plan->is_active ? 'green' : 'red'); ?>">
                  <?php echo e($plan->is_active ? 'Actif' : 'Inactif'); ?>

                </span>
              </td>

              
              <td>
                <div class="actions" style="justify-content:flex-end">
                  <a href="<?php echo e(route('admin.plans.edit', $plan)); ?>" class="adm-btn adm-btn--outline adm-btn--sm">Modifier</a>

                  <form method="POST" action="<?php echo e(route('admin.plans.toggle', $plan)); ?>" style="display:inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="adm-btn adm-btn--outline adm-btn--sm"
                            style="color:<?php echo e($plan->is_active ? '#d97706' : '#16a34a'); ?>">
                      <?php echo e($plan->is_active ? 'Désactiver' : 'Activer'); ?>

                    </button>
                  </form>

                  <?php if($plan->abonnements_count === 0): ?>
                  <form method="POST" action="<?php echo e(route('admin.plans.destroy', $plan)); ?>" style="display:inline"
                        onsubmit="return confirm('Supprimer le plan « <?php echo e($plan->name); ?> » ? Cette action est irréversible.')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="adm-btn adm-btn--danger adm-btn--sm">Supprimer</button>
                  </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($plans->isEmpty()): ?>
  <div class="adm-card">
    <div class="adm-empty" style="padding:48px">
      <svg width="36" height="36" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <h3>Aucun plan configuré</h3>
      <p>Créez votre premier plan d'abonnement pour commencer.</p>
      <a href="<?php echo e(route('admin.plans.create')); ?>" class="adm-btn adm-btn--yellow" style="margin-top:12px">Créer un plan</a>
    </div>
  </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/plans/list.blade.php ENDPATH**/ ?>