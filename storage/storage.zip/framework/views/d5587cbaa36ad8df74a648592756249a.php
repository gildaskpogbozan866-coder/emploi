﻿
<?php $__env->startSection('title', 'Services | Administration'); ?>

<?php $__env->startSection('content'); ?>
<div class="adm-topbar">
  <div class="adm-topbar__left">
    <h1>Gestion des services</h1>
    <p><?php echo e(count($services)); ?> service<?php echo e(count($services) > 1 ? 's' : ''); ?> disponible<?php echo e(count($services) > 1 ? 's' : ''); ?></p>
  </div>
  <a href="<?php echo e(route('admin.services.create')); ?>" class="adm-btn adm-btn--yellow">
    <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    Nouveau service
  </a>
</div>

<div class="adm-card">
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>Nom</th><th>Type</th><th>Prix</th><th>Délai</th><th>Commandes</th><th>Actif</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td>
            <div style="font-weight:600;color:#042C53"><?php echo e($service->nom); ?></div>
            <?php if($service->description): ?>
              <div style="font-size:12px;color:#94a3b8"><?php echo e(Str::limit($service->description, 60)); ?></div>
            <?php endif; ?>
          </td>
          <td style="color:#64748b;font-size:13px"><?php echo e($service->type ?? '-'); ?></td>
          <td style="font-weight:700;color:#185FA5"><?php echo e(number_format($service->prix, 0, ',', ' ')); ?> FCFA</td>
          <td style="color:#64748b;font-size:13px"><?php echo e($service->delai ?? '-'); ?></td>
          <td style="text-align:center"><strong><?php echo e($service->commandes_count); ?></strong></td>
          <td>
            <span class="adm-badge adm-badge--<?php echo e($service->actif ? 'green' : 'red'); ?>">
              <?php echo e($service->actif ? 'Actif' : 'Inactif'); ?>

            </span>
          </td>
          <td>
            <div class="actions">
              <a href="<?php echo e(route('admin.services.edit', $service)); ?>" class="adm-btn adm-btn--outline adm-btn--sm">Modifier</a>
              <a href="<?php echo e(route('service.detail', $service)); ?>" target="_blank" class="adm-btn adm-btn--outline adm-btn--sm">Voir</a>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="7">
            <div class="adm-empty">
              <svg width="32" height="32" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
              <h3>Aucun service créé</h3>
              <p><a href="<?php echo e(route('admin.services.create')); ?>" class="adm-btn adm-btn--yellow adm-btn--sm" style="margin-top:8px">Créer un service</a></p>
            </div>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\emploi\resources\views/admin/services/list.blade.php ENDPATH**/ ?>