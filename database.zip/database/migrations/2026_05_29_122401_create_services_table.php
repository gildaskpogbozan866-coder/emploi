<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('services', function (Blueprint $table) {
            $table->id();
            $table->string('nom');
            $table->string('slug')->unique();
            $table->text('description');
            $table->text('details')->nullable();
            $table->integer('prix');
            $table->string('devise')->default('FCFA');
            $table->string('delai')->nullable();
            $table->string('type')->nullable();
            $table->boolean('actif')->default(true);
            $table->integer('nb_commandes')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('services');
    }
};
