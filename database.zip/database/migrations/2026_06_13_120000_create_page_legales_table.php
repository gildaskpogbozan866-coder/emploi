<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('page_legales', function (Blueprint $table) {
            $table->id();
            $table->string('slug', 60)->unique();
            $table->string('titre', 150);
            $table->longText('contenu')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('page_legales');
    }
};
