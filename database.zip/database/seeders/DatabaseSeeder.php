<?php

namespace Database\Seeders;

use App\Enums\Role;
use App\Models\User;
use App\Models\Offre;
use App\Models\CV;
use App\Models\Service;
use App\Models\Article;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ── ÉTAPE 1 : Rôles & Permissions (Spatie) ──────────
        $this->call(RolesAndPermissionsSeeder::class);

        // ── ÉTAPE 1b : Référentiels métier ───────────────────
        $this->call(NiveauxLangueSeeder::class);
        $this->call(LanguesSeeder::class);
        $this->call(NiveauxEtudesSeeder::class);
        $this->call(NiveauxExperienceSeeder::class);
        $this->call(TypeContratsSeeder::class);
        $this->call(SecteursActiviteSeeder::class);
        $this->call(MetiersSeeder::class);
        $this->call(CompetencesSeeder::class);
        $this->call(MetierCompetenceSeeder::class);
        $this->call(TypeDocumentSeeder::class);
        $this->call(PlansSeeder::class);
        $this->call(JobPublicationPlansSeeder::class);

        // ── ÉTAPE 2 : Utilisateurs ────────────────────────────
        $admin = User::firstOrCreate(['email' => 'admin@emploibougebenin.com'], [
            'prenom'            => 'Super',
            'nom'               => 'Admin',
            'password'          => Hash::make('Admin@2026'),
            'role'              => Role::ADMIN,
            'pays'              => 'Bénin',
            'actif'             => true,
            'email_verified_at' => now(),
        ]);
        $admin->syncRoles([Role::ADMIN]);

        $recruteur1 = User::firstOrCreate(['email' => 'recruteur@techbenin.com'], [
            'prenom'            => 'Kokou',
            'nom'               => 'Ahonou',
            'password'          => Hash::make('password'),
            'role'              => Role::RECRUTEUR,
            'entreprise'        => 'TechBénin SARL',
            'pays'              => 'Bénin',
            'actif'             => true,
            'email_verified_at' => now(),
        ]);
        $recruteur1->syncRoles([Role::RECRUTEUR]);

        $recruteur2 = User::firstOrCreate(['email' => 'rh@senservices.sn'], [
            'prenom'            => 'Fatou',
            'nom'               => 'Diallo',
            'password'          => Hash::make('password'),
            'role'              => Role::RECRUTEUR,
            'entreprise'        => 'SenServices SA',
            'pays'              => 'Sénégal',
            'actif'             => true,
            'email_verified_at' => now(),
        ]);
        $recruteur2->syncRoles([Role::RECRUTEUR]);

        $candidat1 = User::firstOrCreate(['email' => 'jb.kpossou@gmail.com'], [
            'prenom'            => 'Jean-Baptiste',
            'nom'               => 'Kpossou',
            'password'          => Hash::make('password'),
            'role'              => Role::CANDIDAT,
            'pays'              => 'Bénin',
            'actif'             => true,
            'email_verified_at' => now(),
        ]);
        $candidat1->syncRoles([Role::CANDIDAT]);

        $candidat2 = User::firstOrCreate(['email' => 'aissatou.traore@gmail.com'], [
            'prenom'            => 'Aïssatou',
            'nom'               => 'Traoré',
            'password'          => Hash::make('password'),
            'role'              => Role::CANDIDAT,
            'pays'              => "Côte d'Ivoire",
            'actif'             => true,
            'email_verified_at' => now(),
        ]);
        $candidat2->syncRoles([Role::CANDIDAT]);

        $candidat3 = User::firstOrCreate(['email' => 'moussa.diarra@gmail.com'], [
            'prenom'            => 'Moussa',
            'nom'               => 'Diarra',
            'password'          => Hash::make('password'),
            'role'              => Role::CANDIDAT,
            'pays'              => 'Mali',
            'actif'             => true,
            'email_verified_at' => now(),
        ]);
        $candidat3->syncRoles([Role::CANDIDAT]);

        // ── ÉTAPE 3 : Données métier ─────────────────────────
        CV::firstOrCreate(
            ['candidat_id' => $candidat1->id],
            [
               
                'plan'        => 'gratuit',
                'visible'     => true,
            ]
        );

        CV::firstOrCreate(
            ['candidat_id' => $candidat2->id, ],
            [
                
                'plan'        => 'gratuit',
                'visible'     => true,
            ]
        );

        $offresData = [
            ['titre' => 'Développeur Web Full Stack',     'type_contrat_id' => 1,   'secteur' => 'Informatique', 'salaire' => '150 000 - 250 000 FCFA'],
            ['titre' => 'Chargé(e) de Marketing Digital', 'type_contrat_id' => 1,   'secteur' => 'Marketing',    'salaire' => '120 000 FCFA'],
            ['titre' => 'Stage en Comptabilité',          'type_contrat_id' => 2, 'secteur' => 'Finance',      'salaire' => '50 000 FCFA/mois'],
            ['titre' => 'Responsable Ressources Humaines','type_contrat_id' => 3,   'secteur' => 'RH',           'salaire' => '200 000 - 300 000 FCFA'],
            ['titre' => 'Bourse de formation Data Science','type_contrat_id'=> 3,'secteur' => 'Formation',    'salaire' => 'Gratuit + Allocation'],
            ['titre' => 'Commercial terrain B2B',         'type_contrat_id' => 3,   'secteur' => 'Ventes',       'salaire' => 'Fixe + Commissions'],
        ];

        foreach ($offresData as $i => $data) {
            $recruteurId = ($i % 2 === 0) ? $recruteur1->id : $recruteur2->id;
            Offre::firstOrCreate(
                ['recruteur_id' => $recruteurId, 'titre' => $data['titre']],
                [
                    'entreprise'   => ($i % 2 === 0) ? 'TechBénin SARL' : 'SenServices SA',
                    'localisation' => ($i % 2 === 0) ? 'Cotonou, Bénin' : 'Dakar, Sénégal',
                    'type_contrat_id'         => $data['type_contrat_id'],
                    'secteur'      => $data['secteur'],
                    'salaire'      => $data['salaire'],
                    'description'  => "Nous recherchons un(e) {$data['titre']} motivé(e) pour rejoindre notre équipe. Venez contribuer à nos projets dans un environnement stimulant.",
                    'statut'       => 'active',
                    'date_limite'  => now()->addDays(30),
                ]
            );
        }

        $servicesData = [
            ['nom' => 'CV Professionnel + Lettre de Motivation', 'slug' => 'cv-professionnel',
             'description' => 'Nos experts rédigent pour vous un CV percutant et une lettre de motivation convaincante.',
             'details' => 'Analyse du profil · CV ATS-optimisé · Lettre personnalisée · Livraison Word + PDF sous 48h · 1 révision gratuite',
             'prix' => 2500, 'delai' => '48h', 'type' => 'redaction'],
            ['nom' => 'Profil LinkedIn Optimisé', 'slug' => 'linkedin-optimise',
             'description' => 'Optimisez votre présence LinkedIn pour attirer les recruteurs.',
             'details' => 'Audit du profil · Rédaction complète · Mots-clés SEO LinkedIn · Livraison sous 72h',
             'prix' => 3500, 'delai' => '72h', 'type' => 'redaction'],
            ['nom' => 'Coaching Entretien', 'slug' => 'coaching-entretien',
             'description' => 'Préparez-vous à décrocher le poste avec un coaching personnalisé.',
             'details' => "1h session vidéo · Simulation entretien · Feedback détaillé · Plan d'amélioration",
             'prix' => 5000, 'delai' => 'Sur rendez-vous', 'type' => 'coaching'],
        ];

        foreach ($servicesData as $s) {
            Service::updateOrCreate(['slug' => $s['slug']], $s + ['actif' => true]);
        }

        $articlesData = [
            ['titre' => 'Comment rédiger un CV qui attire les recruteurs en 2026',
             'slug'  => 'rediger-cv-2026',
             'extrait' => 'Découvrez les erreurs à éviter et les astuces pour créer un CV percutant adapté au marché africain.',
             'categorie' => 'Conseils CV', 'temps_lecture' => 5],
            ['titre' => 'Les 10 questions les plus fréquentes en entretien',
             'slug'  => 'questions-entretien-frequentes',
             'extrait' => 'Préparez-vous avec nos réponses types et stratégies pour convaincre chaque recruteur.',
             'categorie' => 'Entretien', 'temps_lecture' => 7],
            ['titre' => "Trouver un emploi à distance depuis l'Afrique : guide complet",
             'slug'  => 'emploi-remote-afrique',
             'extrait' => "Plateformes, profils, tarifs : tout ce qu'il faut pour décrocher votre premier job remote.",
             'categorie' => 'Remote', 'temps_lecture' => 6],
        ];

        foreach ($articlesData as $a) {
            Article::updateOrCreate(['slug' => $a['slug']], $a + [
                'auteur_id' => $admin->id,
                'contenu'   => '<p>Article complet à rédiger...</p>',
                'statut'    => 'publie',
                'publie_le' => now(),
            ]);
        }

        $this->command->info('✅ Données de démonstration insérées.');
    }
}
