<?php

return [
    'reset'     => 'Votre mot de passe a été réinitialisé.',
    'sent'      => 'Nous vous avons envoyé par e-mail le lien de réinitialisation du mot de passe.',
    'throttled' => 'Veuillez patienter avant de réessayer.',
    'token'     => 'Ce jeton de réinitialisation du mot de passe n\'est pas valide.',
    'user'      => 'Aucun utilisateur trouvé avec cette adresse e-mail.',
];
