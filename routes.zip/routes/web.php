<?php

use App\Enums\Permission;
use App\Enums\Role;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\GoogleController;
use App\Http\Controllers\Public\HomeController;
use App\Http\Controllers\Public\OffreController;
use App\Http\Controllers\Public\ServiceController;
use App\Http\Controllers\Public\BlogController;
use App\Http\Controllers\Public\ContactController;
use App\Http\Controllers\Candidat\DashboardController as CandidatDashboard;
use App\Http\Controllers\Candidat\CandidatureController;
use App\Http\Controllers\Candidat\CVController;
use App\Http\Controllers\Candidat\ProfilController as CandidatProfil;
use App\Http\Controllers\Candidat\ExperienceController;
use App\Http\Controllers\Candidat\FormationController;
use App\Http\Controllers\Candidat\CompetenceController;
use App\Http\Controllers\Candidat\RealisationController as CandidatRealisationCtrl;
use App\Http\Controllers\Candidat\DocumentController as CandidatDocumentCtrl;
use App\Http\Controllers\Candidat\LangueController;
use App\Http\Controllers\Candidat\AlerteController;
use App\Http\Controllers\Candidat\MessageController as CandidatMessage;
use App\Http\Controllers\Candidat\AbonnementController as CandidatAbonnement;
use App\Http\Controllers\Candidat\NotificationController;
use App\Http\Controllers\Recruteur\DashboardController as RecruteurDashboard;
use App\Http\Controllers\Recruteur\OffreController as RecruteurOffre;
use App\Http\Controllers\Recruteur\CandidatureController as RecruteurCandidature;
use App\Http\Controllers\Recruteur\CvthequeController;
use App\Http\Controllers\Recruteur\CvCreditsController;
use App\Http\Controllers\Recruteur\PaiementController as RecruteurPaiement;
use App\Http\Controllers\Candidat\PaiementController as CandidatPaiement;
use App\Http\Controllers\Payment\GatewayController;
use App\Http\Controllers\Payment\CallbackController;
use App\Http\Controllers\Payment\StatusController;
use App\Http\Controllers\Payment\WebhookController;
use App\Http\Controllers\Admin\PaymentSettingsController;
use App\Http\Controllers\Recruteur\MessageController as RecruteurMessage;
use App\Http\Controllers\Recruteur\AbonnementController as RecruteurAbonnement;
use App\Http\Controllers\Recruteur\StatistiqueController as RecruteurStat;
use App\Http\Controllers\Recruteur\ProfilController as RecruteurProfil;
use App\Http\Controllers\Admin\DashboardController as AdminDashboard;
use App\Http\Controllers\Admin\UtilisateurController;
use App\Http\Controllers\Admin\OffreController as AdminOffre;
use App\Http\Controllers\Admin\CVController as AdminCV;
use App\Http\Controllers\Admin\DocumentController as AdminDocument;
use App\Http\Controllers\Admin\BlogController as AdminBlog;
use App\Http\Controllers\Admin\ServiceController as AdminService;
use App\Http\Controllers\Admin\PaiementController as AdminPaiement;
use App\Http\Controllers\Admin\AbonnementController as AdminAbonnement;
use App\Http\Controllers\Admin\PlanController as AdminPlan;
use App\Http\Controllers\Admin\MessageController as AdminMessage;
use App\Http\Controllers\Admin\SignalementController;
use App\Http\Controllers\Admin\StatistiqueController as AdminStat;
use App\Http\Controllers\Admin\ParametreController as AdminParametre;
use App\Http\Controllers\Admin\PermissionController;
use App\Http\Controllers\Admin\SeoController as AdminSeo;
use App\Http\Controllers\Public\SitemapController;
use App\Http\Controllers\Public\SeoLandingController;
use App\Http\Controllers\Admin\VerificationRecruteurController;
use App\Http\Controllers\Admin\RecruteurDocumentTypeController;
use App\Http\Controllers\Admin\ContactMessageController as AdminContactMessage;
use App\Http\Controllers\Public\LegaleController;
use App\Http\Controllers\Admin\PageLegaleController as AdminPageLegale;
use App\Http\Controllers\Admin\FaqController as AdminFaq;
use App\Http\Controllers\Admin\JobPublicationPlanController as AdminJobPubPlan;
use App\Http\Controllers\Admin\CreditCvPackController as AdminCreditCvPack;
use App\Models\RecruteurDocument;
use App\Http\Controllers\Admin\Referentiel\CompetencesController as AdminCompetences;
use App\Http\Controllers\Admin\Referentiel\MetiersController as AdminMetiers;
use App\Http\Controllers\Admin\Referentiel\TypeContratsController as AdminTypeContrats;
use App\Http\Controllers\Admin\Referentiel\SecteursActiviteController as AdminSecteursActivite;
use App\Http\Controllers\Admin\Referentiel\LanguesController as AdminLangues;
use App\Http\Controllers\Admin\Referentiel\NiveauxLangueController as AdminNiveauxLangue;
use App\Http\Controllers\Admin\Referentiel\NiveauxEtudeController as AdminNiveauxEtude;
use App\Http\Controllers\Admin\Referentiel\NiveauxExperienceController as AdminNiveauxExperience;
use App\Http\Controllers\Admin\Referentiel\DisponibilitesController as AdminDisponibilites;
use App\Http\Controllers\Admin\Referentiel\RegionsController as AdminRegions;
use App\Http\Controllers\Recruteur\VerificationController as RecruteurVerifCtrl;
use App\Http\Controllers\Annonceur\DashboardController as AnnonceurDashboard;
use App\Http\Controllers\Annonceur\PubliciteController as AnnonceurPublicite;
use App\Http\Controllers\Admin\PubliciteController as AdminPublicite;
use App\Http\Controllers\Admin\PartenaireController as AdminPartenaire;
use App\Http\Controllers\Public\PubliciteController as PublicPublicite;
use App\Http\Controllers\NewsletterController;
use App\Http\Controllers\Admin\NewsletterController as AdminNewsletter;
use App\Http\Controllers\Admin\NotificationController as AdminNotification;
use App\Http\Controllers\Recruteur\NotificationController as RecruteurNotification;
use App\Http\Controllers\Annonceur\NotificationController as AnnonceurNotification;
use App\Models\ParametreApp;
use Illuminate\Foundation\Auth\EmailVerificationRequest;

// API publique — annonces actives pour le widget homepage
Route::get('/api/publicites/actives', [PublicPublicite::class, 'actives'])->name('publicites.actives');

// PWA manifest dynamique
Route::get('/manifest.json', function () {
    return response()->json([
        'name'             => 'Emploi Bouge Bénin',
        'short_name'       => 'Emploi Bénin',
        'description'      => 'Plateforme emploi au Bénin — offres vérifiées, CV en ligne, recrutement et talents.',
        'start_url'        => '/',
        'scope'            => '/',
        'display'          => 'standalone',
        'orientation'      => 'portrait',
        'background_color' => '#ffffff',
        'theme_color'      => '#042C53',
        'lang'             => 'fr',
        'icons'            => [
            ['src' => asset('images/pwa-icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
            ['src' => asset('images/pwa-icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'maskable'],
            ['src' => asset('images/pwa-icon-512.png'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
            ['src' => asset('images/pwa-icon-512.png'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
        ],
        'categories' => ['business', 'productivity'],
    ])->header('Content-Type', 'application/manifest+json');
})->name('pwa.manifest');

// Page publique des affichages publicitaires
Route::get('/affichages-publicitaires', [PublicPublicite::class, 'index'])->name('publicites.index');

// ════════════════════════════════════════════════════════
//  PAGES PUBLIQUES
// ════════════════════════════════════════════════════════
// ════════════════════════════════════════════════════════
//  SEO — sitemap.xml et robots.txt
// ════════════════════════════════════════════════════════
Route::get('/sitemap.xml', [SitemapController::class, 'sitemap'])->name('sitemap');
Route::get('/robots.txt',  [SitemapController::class, 'robots'])->name('robots');

// ════════════════════════════════════════════════════════
//  SEO Landing Pages — mots-clés cibles
// ════════════════════════════════════════════════════════
Route::get('/emploi-cotonou',       [SeoLandingController::class, 'emploiCotonou'])->name('seo.emploi-cotonou');
Route::get('/recrutement-benin',    [SeoLandingController::class, 'recrutementBenin'])->name('seo.recrutement-benin');
Route::get('/stage-benin',          [SeoLandingController::class, 'stageBenin'])->name('seo.stage-benin');

// Newsletter publique
Route::post('/newsletter/abonner',           [NewsletterController::class, 'abonner'])->name('newsletter.abonner');
Route::get('/newsletter/desabonner/{token}', [NewsletterController::class, 'desabonner'])->name('newsletter.desabonner');

Route::get('/',          [HomeController::class, 'index'])->name('home');
Route::get('/a-propos',  [HomeController::class, 'aPropos'])->name('a-propos');
Route::get('/contact',   [HomeController::class, 'contact'])->name('contact');
Route::get('/faq',       [HomeController::class, 'faq'])->name('faq');
Route::post('/contact',  [ContactController::class, 'envoyer'])->name('contact.envoyer');

// Pages légales
Route::prefix('legale')->name('legale.')->group(function () {
    Route::get('/{slug}', [LegaleController::class, 'show'])->name('show');
});

// Offres publiques
Route::prefix('offres')->name('offre.')->group(function () {
    Route::get('/',               [OffreController::class, 'index'])->name('list');
    Route::get('/{offre}',        [OffreController::class, 'detail'])->name('detail');
    Route::get('/{offre}/postuler',[OffreController::class, 'postuler'])->name('postuler');
    Route::post('/{offre}/postuler',[OffreController::class, 'storerCandidature'])->name('postuler.store')->middleware('auth');
    Route::get('/{offre}/succes', [OffreController::class, 'candidatureSucces'])->name('candidature-succes');
    Route::get('/publier/formulaire',[OffreController::class, 'publier'])->name('publier');
    Route::post('/publier',       [OffreController::class, 'storerOffre'])->name('publier.store')->middleware('auth');
    Route::get('/{offre}/publiee',[OffreController::class, 'offrePublieeSucces'])->name('publiee-succes');
});

// CVthèque et dépôt CV publics
Route::prefix('cvs')->name('cv.public.')->group(function () {
    Route::get('/',          [CVController::class, 'theque'])->name('theque');
    Route::get('/tarif',     [CVController::class, 'tarif'])->name('tarif');
    Route::middleware(['candidat.profil-complet', 'permission:'.Permission::DEPOSIT_CV])->group(function () {

    Route::get('/deposer',   [CVController::class, 'depot'])->name('depot');
    Route::post('/deposer',  [CVController::class, 'store'])->name('depot.store')->middleware('auth');
    });
    Route::get('/{cv}',      [CVController::class, 'detail'])->name('detail');
});

Route::get('/documents/{document}', [CVController::class, 'candidatDetails'])->name('document.public.detail');
Route::get('/candidat/{$id}/profil', [CVController::class, 'documentDetail'])->name('public.candidat.detail');

// Services
Route::prefix('services')->name('service.')->group(function () {
    Route::get('/',                   [ServiceController::class, 'index'])->name('list');
    Route::get('/{service}',          [ServiceController::class, 'detail'])->name('detail');
    Route::get('/{service}/commander',[ServiceController::class, 'commander'])->name('commande');
    Route::post('/{service}/commander',[ServiceController::class,'storerCommande'])->name('commande.store');
    Route::get('/commande/succes',    [ServiceController::class, 'succes'])->name('succes');
});

// Blog
Route::prefix('blog')->name('blog.')->group(function () {
    Route::get('/',          [BlogController::class, 'index'])->name('list');
    Route::get('/{article}', [BlogController::class, 'detail'])->name('detail');
});

// ════════════════════════════════════════════════════════
//  PAIEMENT — Webhooks (sans CSRF), Callbacks, Status
// ════════════════════════════════════════════════════════

// Webhooks push serveur-à-serveur (CSRF-exempt, voir bootstrap/app.php)
Route::post('/payment/webhook/fedapay', [WebhookController::class, 'fedapay'])->name('payment.webhook.fedapay');

// Paiement — accessible sans compte (sécurisé par token sur le paiement)
Route::prefix('payment')->name('payment.')->group(function () {
    Route::get('/choisir/{paiement}',          [GatewayController::class, 'choose'])->name('choose');
    Route::post('/lancer/{paiement}',          [GatewayController::class, 'initiate'])->name('initiate');
    Route::get('/callback/fedapay/{paiement}', [CallbackController::class, 'fedapay'])->name('callback.fedapay');
    Route::post('/callback/kkiapay',           [CallbackController::class, 'kkiapay'])->name('callback.kkiapay');
    Route::get('/succes/{paiement}',           [StatusController::class, 'success'])->name('success');
    Route::get('/echec/{paiement}',            [StatusController::class, 'failed'])->name('failed');
    Route::get('/en-attente/{paiement}',       [StatusController::class, 'pending'])->name('pending');
});

// ════════════════════════════════════════════════════════
//  AUTHENTIFICATION (email + mot de passe)
// ════════════════════════════════════════════════════════
Route::prefix('auth')->name('auth.')->group(function () {
    Route::get('/connexion',           [AuthController::class, 'showConnexion'])->name('connexion');
    Route::get('/inscription',         [AuthController::class, 'showInscription'])->name('inscription');
    Route::get('/compte-confirme',     [AuthController::class, 'showCompteConfirme'])->name('compte-confirme');
    Route::get('/mot-de-passe-oublie', [AuthController::class, 'showMotDePasseOublie'])->name('mot-de-passe-oublie');
    Route::get('/reinitialiser/{token}', [AuthController::class, 'showReinitialisation'])->name('reinitialiser');

    Route::post('/connexion',           [AuthController::class, 'connecter'])->name('connexion.store')->middleware('throttle:10,1');
    Route::post('/inscription',         [AuthController::class, 'inscrire'])->name('inscription.store');
    Route::post('/mot-de-passe-oublie', [AuthController::class, 'envoyerLienReinitialisation'])->name('mot-de-passe-oublie.store');
    Route::post('/reinitialiser',       [AuthController::class, 'reinitialiserMotDePasse'])->name('reinitialiser.store');

    Route::get('/changer-mot-de-passe',  [AuthController::class, 'showChangerMotDePasse'])->name('changer-mot-de-passe')->middleware('auth');
    Route::post('/changer-mot-de-passe', [AuthController::class, 'changerMotDePasse'])->name('changer-mot-de-passe.store')->middleware('auth');

    Route::post('/deconnecter', [AuthController::class, 'deconnecter'])->name('deconnecter')->middleware('auth');

    // Google OAuth
    Route::get('/google',          [GoogleController::class, 'redirect'])->name('google');
    Route::get('/google/callback', [GoogleController::class, 'callback'])->name('google.callback');
    Route::get('/google/role',     [GoogleController::class, 'showRoleSelect'])->name('google.role');
    Route::post('/google/create',  [GoogleController::class, 'createWithRole'])->name('google.create');
});

// ════════════════════════════════════════════════════════
//  VÉRIFICATION EMAIL (Laravel natif)
// ════════════════════════════════════════════════════════
Route::middleware('auth')->group(function () {
    Route::get('/email/verifier', function () {
        $user = auth()->user();
        if ($user->hasVerifiedEmail()) {
            $validationDocsActif = \App\Models\ParametreApp::get('recruteur_validation_docs', '0') === '1';
            return match ($user->role) {
                'admin'     => redirect()->route('admin.dashboard'),
                'recruteur' => $validationDocsActif
                                ? redirect()->route('recruteur.verification')
                                : redirect()->route('recruteur.dashboard'),
                'annonceur' => redirect()->route('annonceur.dashboard'),
                default     => redirect()->route('candidat.dashboard'),
            };
        }
        return view('auth.verify-email');
    })->name('verification.notice');

    Route::get('/email/verifier/{id}/{hash}', function (EmailVerificationRequest $request) {
        $request->fulfill();
        $user                  = $request->user();
        $validationDocsActif   = ParametreApp::get('recruteur_validation_docs', '0') === '1';

        if ($user->role === 'recruteur') {
            return $validationDocsActif
                ? redirect()->route('recruteur.verification')
                : redirect()->route('recruteur.dashboard');
        }

        return match ($user->role) {
            'admin'     => redirect()->route('admin.dashboard'),
            'annonceur' => redirect()->route('annonceur.dashboard'),
            default     => redirect()->route('candidat.dashboard'),
        };
    })->middleware('signed')->name('verification.verify');

    Route::post('/email/renvoyer', function (Illuminate\Http\Request $request) {
        if ($request->user()->hasVerifiedEmail()) {
            return redirect()->intended(route('home'));
        }
        $request->user()->sendEmailVerificationNotification();
        return back()->with('resent', true);
    })->middleware('throttle:6,1')->name('verification.send');
});

// ════════════════════════════════════════════════════════
//  ESPACE CANDIDAT — protégé par rôle + permissions
// ════════════════════════════════════════════════════════
Route::prefix('candidat')->name('candidat.')->middleware(['auth', 'verified', 'spatie.role:'.Role::CANDIDAT])->group(function () {
    Route::get('/tableau-de-bord', [CandidatDashboard::class, 'index'])->name('dashboard');

    // CVs — nécessite permission deposit-cv + profil complet
    Route::middleware(['candidat.profil-complet', 'permission:'.Permission::DEPOSIT_CV])->group(function () {
        Route::get('/mes-cvs',                        [CVController::class, 'index'])->name('cvs');
        Route::get('/mes-cvs/modifier/{cv}',          [CVController::class, 'edit'])->name('cvs.edit');
        Route::put('/mes-cvs/{cv}',                   [CVController::class, 'update'])->name('cvs.update');
        Route::delete('/mes-cvs/{cv}',                [CVController::class, 'destroy'])->name('cvs.destroy');
        Route::patch('/mes-cvs/{cv}/visibilite',      [CVController::class, 'toggleVisibilite'])->name('cvs.visibilite');
    });

    // Candidatures — nécessite apply-offre + profil complet
    Route::middleware(['candidat.profil-complet', 'permission:'.Permission::APPLY_OFFRE])->group(function () {
        Route::get('/mes-candidatures',               [CandidatureController::class, 'index'])->name('candidatures');
        Route::get('/mes-candidatures/{candidature}', [CandidatureController::class, 'detail'])->name('candidatures.detail');
    });

    // Offres sauvegardées — nécessite save-offre
    Route::middleware('permission:'.Permission::SAVE_OFFRE)->group(function () {
        Route::get('/offres-sauvegardees',           [CandidatureController::class, 'offresSauvegardees'])->name('offres-sauvegardees');
        Route::post('/offres-sauvegardees/{offre}',  [CandidatureController::class, 'sauvegarder'])->name('offres-sauvegardees.toggle');
    });

    // Alertes — nécessite create-alerte
    Route::middleware('permission:'.Permission::CREATE_ALERTE)->group(function () {
        Route::get('/mes-alertes',                      [AlerteController::class, 'index'])->name('alertes');
        Route::post('/mes-alertes',                     [AlerteController::class, 'store'])->name('alertes.store');
        Route::patch('/mes-alertes/{alerte}/toggle',    [AlerteController::class, 'toggle'])->name('alertes.toggle');
        Route::delete('/mes-alertes/{alerte}',          [AlerteController::class, 'destroy'])->name('alertes.destroy');
    });

    // Abonnement — nécessite manage-abonnement-candidat
    Route::middleware('permission:'.Permission::MANAGE_ABONNEMENT_CAN)->group(function () {
        Route::get('/abonnement',                [CandidatAbonnement::class, 'index'])->name('abonnement');
        Route::get('/abonnement/plans',          [CandidatAbonnement::class, 'choisirPlan'])->name('abonnement.plans');
        Route::get('/abonnement/pourquoi-premium',[CandidatAbonnement::class, 'pourquoiPremium'])->name('abonnement.pourquoi');
        Route::post('/abonnement',               [CandidatAbonnement::class, 'souscrire'])->name('abonnement.store');
    });

    // Messagerie (accessibles à tous les candidats authentifiés)
    Route::get('/messagerie',                                      [CandidatMessage::class, 'index'])->name('messagerie');
    Route::post('/messagerie/initier/{user}',                      [CandidatMessage::class, 'initier'])->name('messagerie.initier');
    Route::get('/messagerie/{conversation}',                       [CandidatMessage::class, 'show'])->name('messagerie.show');
    Route::post('/messagerie/{conversation}',                      [CandidatMessage::class, 'store'])->name('messagerie.store');
    Route::get('/messagerie/{conversation}/rafraichir',            [CandidatMessage::class, 'rafraichir'])->name('messagerie.rafraichir');
    Route::post('/messagerie/{conversation}/archiver',             [CandidatMessage::class, 'archiver'])->name('messagerie.archiver');
    Route::get('/notifications',            [NotificationController::class, 'index'])->name('notifications');
    Route::post('/notifications/marquer',   [NotificationController::class, 'marquerLues'])->name('notifications.lues');
    Route::get('/paiements',               [CandidatPaiement::class, 'index'])->name('paiements');
    Route::get('/profil',                  [CandidatProfil::class, 'edit'])->name('profil');
    Route::put('/profil',                  [CandidatProfil::class, 'update'])->name('profil.update');
    Route::post('/profil/avatar',          [CandidatProfil::class, 'updateAvatar'])->name('profil.avatar.update');
    Route::delete('/profil/avatar',        [CandidatProfil::class, 'deleteAvatar'])->name('profil.avatar.delete');
    Route::get('/parametres',              [CandidatProfil::class, 'parametres'])->name('parametres');
    Route::put('/parametres',              [CandidatProfil::class, 'updateParametres'])->name('parametres.update');

    // Expériences (AJAX)
    Route::post('/profil/experiences',              [ExperienceController::class, 'store'])->name('profil.experiences.store');
    Route::put('/profil/experiences/{experience}',  [ExperienceController::class, 'update'])->name('profil.experiences.update');
    Route::delete('/profil/experiences/{experience}',[ExperienceController::class, 'destroy'])->name('profil.experiences.destroy');

    // Formations (AJAX)
    Route::post('/profil/formations',              [FormationController::class, 'store'])->name('profil.formations.store');
    Route::put('/profil/formations/{formation}',   [FormationController::class, 'update'])->name('profil.formations.update');
    Route::delete('/profil/formations/{formation}',[FormationController::class, 'destroy'])->name('profil.formations.destroy');

    // Compétences (AJAX)
    Route::post('/profil/competences',               [CompetenceController::class, 'store'])->name('profil.competences.store');
    Route::delete('/profil/competences/{competence}',[CompetenceController::class, 'destroy'])->name('profil.competences.destroy');

    // Langues (AJAX)
    Route::post('/profil/langues',           [LangueController::class, 'store'])->name('profil.langues.store');
    Route::delete('/profil/langues/{langue}',[LangueController::class, 'destroy'])->name('profil.langues.destroy');

    // Réalisations (portfolio photos)
    Route::post('/profil/realisations',                    [CandidatRealisationCtrl::class, 'store'])->name('realisations.store');
    Route::delete('/profil/realisations/{realisation}',    [CandidatRealisationCtrl::class, 'destroy'])->name('realisations.delete');

    // Documents (CV, diplômes, attestations…)
    Route::post('/profil/documents',                [CandidatDocumentCtrl::class, 'store'])->name('documents.store');
    Route::get('/profil/documents/{document}/edit', [CandidatDocumentCtrl::class, 'edit'])->name('documents.edit');
    Route::put('/profil/documents/{document}',      [CandidatDocumentCtrl::class, 'update'])->name('documents.update');
    Route::delete('/profil/documents/{document}',   [CandidatDocumentCtrl::class, 'destroy'])->name('documents.destroy');
});

// ════════════════════════════════════════════════════════
//  ESPACE RECRUTEUR — protégé par rôle + permissions
// ════════════════════════════════════════════════════════
Route::prefix('recruteur')->name('recruteur.')->middleware(['auth', 'verified', 'spatie.role:'.Role::RECRUTEUR])->group(function () {

    // Vérification du compte entreprise (accessible avant approbation admin)
    Route::get('/verification',             [RecruteurVerifCtrl::class, 'soumettre'])->name('verification');
    Route::post('/verification',            [RecruteurVerifCtrl::class, 'store'])->name('verification.store');
    Route::get('/verification/en-attente',  [RecruteurVerifCtrl::class, 'enAttente'])->name('verification.en-attente');
    Route::get('/verification/rejete',      [RecruteurVerifCtrl::class, 'rejete'])->name('verification.rejete');

    // ── Tout ce qui suit nécessite l'approbation du dossier par l'admin ──
    Route::middleware('recruteur.approuve')->group(function () {

    Route::get('/tableau-de-bord', [RecruteurDashboard::class, 'index'])->name('dashboard');

    // Publication d'offres — nécessite publish-offre
    Route::middleware('permission:'.Permission::PUBLISH_OFFRE)->group(function () {
        Route::get('/mes-offres',                          [RecruteurOffre::class, 'index'])->name('offres');
        Route::get('/mes-offres/creer',                    [RecruteurOffre::class, 'create'])->name('offres.create');
        Route::post('/mes-offres',                         [RecruteurOffre::class, 'store'])->name('offres.store');
        Route::get('/mes-offres/{offre}/modifier',         [RecruteurOffre::class, 'edit'])->name('offres.edit');
        Route::put('/mes-offres/{offre}',                  [RecruteurOffre::class, 'update'])->name('offres.update');
        Route::delete('/mes-offres/{offre}',               [RecruteurOffre::class, 'destroy'])->name('offres.destroy');
        Route::patch('/mes-offres/{offre}/cloturer',        [RecruteurOffre::class, 'cloturer'])->name('offres.cloturer');
        Route::patch('/mes-offres/{offre}/mettre-en-avant',[RecruteurOffre::class, 'mettreEnAvant'])->name('offres.mettre-en-avant');
        Route::post('/mes-offres/{offre}/dupliquer',       [RecruteurOffre::class, 'dupliquer'])->name('offres.dupliquer');
        Route::get('/mes-offres/{offre}/statistiques',     [RecruteurOffre::class, 'stats'])->name('offres.stats');
    });

    // Candidatures — nécessite view-candidatures
    Route::middleware('permission:'.Permission::VIEW_CANDIDATURES)->group(function () {
        Route::get('/candidatures',                   [RecruteurCandidature::class, 'index'])->name('candidatures');
        Route::get('/candidatures/export',            [RecruteurCandidature::class, 'export'])->name('candidatures.export');
        Route::get('/candidatures/{candidature}',     [RecruteurCandidature::class, 'show'])->name('candidatures.show');
        Route::patch('/candidatures/{candidature}/statut', [RecruteurCandidature::class, 'updateStatut'])->name('candidatures.statut');
    });

    // CVthèque — nécessite view-cvtheque
    Route::middleware('permission:'.Permission::VIEW_CVTHEQUE)->group(function () {
        Route::get('/cvtheque',                                    [CvthequeController::class, 'index'])->name('cvtheque');
        Route::get('/cvtheque/favoris',                            [CvthequeController::class, 'favoris'])->name('cvtheque.favoris.list');
        Route::get('/cvtheque/document/{document}',               [CvthequeController::class, 'showDocument'])->name('cvtheque.document.show');
        Route::post('/cvtheque/document/{document}/telecharger',  [CvthequeController::class, 'telechargerDocument'])->name('cvtheque.document.telecharger');
        Route::get('/cvtheque/{cv}',                              [CvthequeController::class, 'show'])->name('cvtheque.show');
        Route::post('/cvtheque/{cv}/telecharger',                 [CvthequeController::class, 'telecharger'])->name('cvtheque.telecharger');
        Route::get('/cvtheque/{cv}/pdf',                          [CvthequeController::class, 'telechargerPdf'])->name('cvtheque.pdf');
        Route::post('/cvtheque/{cv}/favoris',                     [CvthequeController::class, 'toggleFavoris'])->name('cvtheque.favoris');
    });

    // Crédits CVthèque
    Route::prefix('cv-credits')->name('cv-credits.')->group(function () {
        Route::get('/',         [CvCreditsController::class, 'index'])->name('index');
        Route::get('/acheter',  [CvCreditsController::class, 'confirm'])->name('confirm');
        Route::post('/acheter', [CvCreditsController::class, 'store'])->name('store');
    });

    // Contact candidats (messagerie) — nécessite contact-candidats
    Route::middleware('permission:'.Permission::CONTACT_CANDIDATS)->group(function () {
        Route::get('/messagerie',                               [RecruteurMessage::class, 'index'])->name('messagerie');
        Route::post('/messagerie/initier/{user}',               [RecruteurMessage::class, 'initier'])->name('messagerie.initier');
        Route::get('/messagerie/{conversation}',                [RecruteurMessage::class, 'show'])->name('messagerie.show');
        Route::post('/messagerie/{conversation}',               [RecruteurMessage::class, 'store'])->name('messagerie.store');
        Route::get('/messagerie/{conversation}/rafraichir',     [RecruteurMessage::class, 'rafraichir'])->name('messagerie.rafraichir');
        Route::post('/messagerie/{conversation}/archiver',      [RecruteurMessage::class, 'archiver'])->name('messagerie.archiver');
    });

    // Abonnement recruteur
    Route::middleware('permission:'.Permission::MANAGE_ABONNEMENT_REC)->group(function () {
        Route::get('/abonnement',       [RecruteurAbonnement::class, 'index'])->name('abonnement');
        Route::get('/abonnement/plans', [RecruteurAbonnement::class, 'choisirPlan'])->name('abonnement.plans');
        Route::post('/abonnement',      [RecruteurAbonnement::class, 'souscrire'])->name('abonnement.store');
    });

    // Historique paiements recruteur
    Route::get('/paiements',        [RecruteurPaiement::class, 'index'])->name('paiements');
    Route::get('/paiements/export', [RecruteurPaiement::class, 'export'])->name('paiements.export');

    Route::get('/statistiques',  [RecruteurStat::class, 'index'])->name('statistiques');
    Route::get('/profil',        [RecruteurProfil::class, 'edit'])->name('profil');
    Route::put('/profil',        [RecruteurProfil::class, 'update'])->name('profil.update');
    Route::get('/parametres',    [RecruteurProfil::class, 'parametres'])->name('parametres');
    Route::put('/parametres',    [RecruteurProfil::class, 'updateParametres'])->name('parametres.update');
    Route::delete('/compte',     [RecruteurProfil::class, 'deleteAccount'])->name('compte.delete');

    }); // fin recruteur.approuve

    // Notifications (accessibles hors approbation)
    Route::get('/notifications',          [RecruteurNotification::class, 'index'])->name('notifications');
    Route::post('/notifications/marquer', function () {
        auth()->user()->notifications()->where('lu', false)->update(['lu' => true]);
        return back()->with('success', 'Notifications marquées comme lues.');
    })->name('notifications.lues');
});

// ════════════════════════════════════════════════════════
//  ESPACE ANNONCEUR — protégé rôle annonceur
// ════════════════════════════════════════════════════════
Route::prefix('annonceur')->name('annonceur.')->middleware(['auth', 'verified', 'spatie.role:'.Role::ANNONCEUR])->group(function () {
    Route::get('/tableau-de-bord',  [AnnonceurDashboard::class, 'index'])->name('dashboard');
    Route::get('/mes-annonces',     [AnnonceurPublicite::class, 'index'])->name('publicites');
    Route::post('/mes-annonces',    [AnnonceurPublicite::class, 'store'])->name('publicites.store');
    Route::delete('/mes-annonces/{publicite}', [AnnonceurPublicite::class, 'destroy'])->name('publicites.destroy');
    Route::get('/notifications',          [AnnonceurNotification::class, 'index'])->name('notifications');
    Route::post('/notifications/marquer', function () {
        auth()->user()->notifications()->where('lu', false)->update(['lu' => true]);
        return back()->with('success', 'Notifications marquées comme lues.');
    })->name('notifications.lues');
});

// ════════════════════════════════════════════════════════
//  ADMINISTRATION — protégé rôle admin + permissions granulaires
// ════════════════════════════════════════════════════════
Route::prefix('admin')->name('admin.')->middleware(['auth', 'spatie.role:'.Role::ADMIN])->group(function () {

    Route::get('/tableau-de-bord', [AdminDashboard::class, 'index'])->name('dashboard');

    // Vérification des comptes recruteurs
    Route::middleware('permission:'.Permission::MANAGE_USERS)->prefix('verifications')->name('verifications.')->group(function () {
        Route::get('/',                           [VerificationRecruteurController::class, 'index'])->name('list');
        Route::get('/{verification}',             [VerificationRecruteurController::class, 'show'])->name('show');
        Route::patch('/{verification}/approuver', [VerificationRecruteurController::class, 'approuver'])->name('approuver');
        Route::patch('/{verification}/rejeter',   [VerificationRecruteurController::class, 'rejeter'])->name('rejeter');
        Route::get('/document/{document}',        [VerificationRecruteurController::class, 'servirDocument'])->name('document');
    });

    // Types de documents recruteur (configuration)
    Route::middleware('permission:'.Permission::MANAGE_USERS)->prefix('document-types')->name('document-types.')->group(function () {
        Route::get('/',           [RecruteurDocumentTypeController::class, 'index'])->name('index');
        Route::post('/',          [RecruteurDocumentTypeController::class, 'store'])->name('store');
        Route::put('/{type}',     [RecruteurDocumentTypeController::class, 'update'])->name('update');
        Route::delete('/{type}',  [RecruteurDocumentTypeController::class, 'destroy'])->name('destroy');
        Route::post('/toggle',    [RecruteurDocumentTypeController::class, 'toggle'])->name('toggle');
    });

    // Gestion utilisateurs
    Route::middleware('permission:'.Permission::MANAGE_USERS)->prefix('utilisateurs')->name('utilisateurs.')->group(function () {
        Route::get('/',                 [UtilisateurController::class, 'index'])->name('list');
        Route::get('/candidats',        [UtilisateurController::class, 'candidats'])->name('candidats');
        Route::get('/recruteurs',       [UtilisateurController::class, 'recruteurs'])->name('recruteurs');
        Route::get('/candidats/{user}', [UtilisateurController::class, 'showCandidat'])->name('candidats.detail');
        Route::get('/recruteurs/{user}',[UtilisateurController::class, 'showRecruteur'])->name('recruteurs.detail');
        Route::patch('/{user}/statut',  [UtilisateurController::class, 'toggleStatut'])->name('statut');
        Route::delete('/{user}',        [UtilisateurController::class, 'destroy'])->name('destroy');
    });

    // Gestion offres
    Route::middleware('permission:'.Permission::MANAGE_OFFRES)->prefix('offres')->name('offres.')->group(function () {
        Route::get('/',                    [AdminOffre::class, 'index'])->name('list');
        Route::get('/{offre}',             [AdminOffre::class, 'show'])->name('detail');
        Route::patch('/{offre}/statut',    [AdminOffre::class, 'updateStatut'])->name('statut');
        Route::delete('/{offre}',          [AdminOffre::class, 'destroy'])->name('destroy');
    });

    // Gestion CVs & Documents
    Route::middleware('permission:'.Permission::MANAGE_CVS)->group(function () {
        Route::prefix('cvs')->name('cvs.')->group(function () {
            Route::get('/',        [AdminCV::class, 'index'])->name('list');
            Route::get('/{cv}',    [AdminCV::class, 'show'])->name('detail');
            Route::delete('/{cv}', [AdminCV::class, 'destroy'])->name('destroy');
        });
        Route::prefix('documents')->name('documents.')->group(function () {
            Route::get('/',             [AdminDocument::class, 'index'])->name('list');
            Route::get('/{document}',   [AdminDocument::class, 'show'])->name('detail');
            Route::delete('/{document}',[AdminDocument::class, 'destroy'])->name('destroy');
        });
    });

    // Gestion blog
    Route::middleware('permission:'.Permission::MANAGE_BLOG)->prefix('blog')->name('blog.')->group(function () {
        Route::get('/',                   [AdminBlog::class, 'index'])->name('list');
        Route::get('/creer',              [AdminBlog::class, 'create'])->name('create');
        Route::post('/',                  [AdminBlog::class, 'store'])->name('store');
        Route::get('/{article}/modifier', [AdminBlog::class, 'edit'])->name('edit');
        Route::put('/{article}',          [AdminBlog::class, 'update'])->name('update');
        Route::delete('/{article}',       [AdminBlog::class, 'destroy'])->name('destroy');
        Route::post('/generer-ia',         [AdminBlog::class, 'genererIA'])->name('generer-ia');
    });

    // Gestion services & commandes
    Route::middleware('permission:'.Permission::MANAGE_SERVICES)->group(function () {
        Route::prefix('services')->name('services.')->group(function () {
            Route::get('/',          [AdminService::class, 'index'])->name('list');
            Route::get('/creer',     [AdminService::class, 'create'])->name('create');
            Route::post('/',         [AdminService::class, 'store'])->name('store');
            Route::get('/{service}/modifier', [AdminService::class, 'edit'])->name('edit');
            Route::put('/{service}', [AdminService::class, 'update'])->name('update');
        });
        Route::middleware('permission:'.Permission::MANAGE_COMMANDES)->prefix('commandes')->name('commandes.')->group(function () {
            Route::get('/',                   [AdminService::class, 'commandes'])->name('list');
            Route::get('/{commande}',         [AdminService::class, 'showCommande'])->name('detail');
            Route::patch('/{commande}/statut',[AdminService::class, 'updateStatut'])->name('statut');
        });
    });

    // Paiements
    Route::middleware('permission:'.Permission::MANAGE_PAIEMENTS)->prefix('paiements')->name('paiements.')->group(function () {
        Route::get('/',              [AdminPaiement::class, 'index'])->name('list');
        Route::get('/export',        [PaymentSettingsController::class, 'export'])->name('export');
        Route::get('/{paiement}',    [AdminPaiement::class, 'show'])->name('detail');
        Route::patch('/{paiement}/statut', [AdminPaiement::class, 'updateStatut'])->name('statut');
    });

    // Configuration des gateways de paiement
    Route::middleware('permission:'.Permission::MANAGE_PAIEMENTS)->prefix('payment-settings')->name('payment-settings.')->group(function () {
        Route::get('/',                    [PaymentSettingsController::class, 'index'])->name('index');
        Route::put('/{gateway}',           [PaymentSettingsController::class, 'update'])->name('update');
    });

    // Abonnements & Plans
    Route::middleware('permission:'.Permission::MANAGE_ABONNEMENTS)->group(function () {
        Route::get('/abonnements', [AdminAbonnement::class, 'index'])->name('abonnements');

        Route::prefix('plans')->name('plans.')->group(function () {
            Route::get('/',                [AdminPlan::class, 'index'])->name('list');
            Route::get('/creer',           [AdminPlan::class, 'create'])->name('create');
            Route::post('/',               [AdminPlan::class, 'store'])->name('store');
            Route::get('/{plan}/modifier', [AdminPlan::class, 'edit'])->name('edit');
            Route::put('/{plan}',          [AdminPlan::class, 'update'])->name('update');
            Route::patch('/{plan}/toggle', [AdminPlan::class, 'toggle'])->name('toggle');
            Route::delete('/{plan}',       [AdminPlan::class, 'destroy'])->name('destroy');
        });

        Route::prefix('credit-cv-packs')->name('credit-cv-packs.')->group(function () {
            Route::get('/',                          [AdminCreditCvPack::class, 'index'])->name('index');
            Route::get('/creer',                     [AdminCreditCvPack::class, 'create'])->name('create');
            Route::post('/',                         [AdminCreditCvPack::class, 'store'])->name('store');
            Route::get('/{creditCvPack}/modifier',   [AdminCreditCvPack::class, 'edit'])->name('edit');
            Route::put('/{creditCvPack}',            [AdminCreditCvPack::class, 'update'])->name('update');
            Route::patch('/{creditCvPack}/toggle',   [AdminCreditCvPack::class, 'toggle'])->name('toggle');
            Route::delete('/{creditCvPack}',         [AdminCreditCvPack::class, 'destroy'])->name('destroy');
        });

        Route::prefix('publication-plans')->name('publication-plans.')->group(function () {
            Route::get('/',                              [AdminJobPubPlan::class, 'index'])->name('index');
            Route::get('/creer',                         [AdminJobPubPlan::class, 'create'])->name('create');
            Route::post('/',                             [AdminJobPubPlan::class, 'store'])->name('store');
            Route::get('/{publicationPlan}/edit',        [AdminJobPubPlan::class, 'edit'])->name('edit');
            Route::put('/{publicationPlan}',             [AdminJobPubPlan::class, 'update'])->name('update');
            Route::patch('/{publicationPlan}/toggle',    [AdminJobPubPlan::class, 'toggle'])->name('toggle');
            Route::delete('/{publicationPlan}',          [AdminJobPubPlan::class, 'destroy'])->name('destroy');
        });
    });

    // Messagerie admin
    Route::middleware('permission:'.Permission::MANAGE_MESSAGERIE)->group(function () {
        Route::get('/messagerie',                   [AdminMessage::class, 'index'])->name('messagerie');
        Route::get('/messagerie/{conversation}',    [AdminMessage::class, 'show'])->name('messagerie.show');
    });

    // FAQ
    Route::prefix('faqs')->name('faqs.')->group(function () {
        Route::get('/',              [AdminFaq::class, 'index'])->name('index');
        Route::get('/creer',         [AdminFaq::class, 'create'])->name('create');
        Route::post('/',             [AdminFaq::class, 'store'])->name('store');
        Route::get('/{faq}/edit',    [AdminFaq::class, 'edit'])->name('edit');
        Route::put('/{faq}',         [AdminFaq::class, 'update'])->name('update');
        Route::delete('/{faq}',      [AdminFaq::class, 'destroy'])->name('destroy');
        Route::patch('/{faq}/toggle',[AdminFaq::class, 'toggleActif'])->name('toggle');
    });

    // Pages légales
    Route::prefix('legales')->name('legales.')->group(function () {
        Route::get('/',             [AdminPageLegale::class, 'index'])->name('index');
        Route::get('/{slug}/edit',  [AdminPageLegale::class, 'edit'])->name('edit');
        Route::put('/{slug}',       [AdminPageLegale::class, 'update'])->name('update');
    });

    // Messages de contact
    Route::prefix('contact-messages')->name('contact-messages.')->group(function () {
        Route::get('/',            [AdminContactMessage::class, 'index'])->name('index');
        Route::get('/{message}',   [AdminContactMessage::class, 'show'])->name('show');
        Route::delete('/{message}',[AdminContactMessage::class, 'destroy'])->name('destroy');
    });

    // Publicités
    Route::middleware('permission:'.Permission::MANAGE_PUBLICITES)->prefix('publicites')->name('publicites.')->group(function () {
        Route::get('/',                            [AdminPublicite::class, 'index'])->name('index');
        Route::get('/{publicite}',                 [AdminPublicite::class, 'show'])->name('show');
        Route::post('/{publicite}/approuver',      [AdminPublicite::class, 'approuver'])->name('approuver');
        Route::post('/{publicite}/rejeter',        [AdminPublicite::class, 'rejeter'])->name('rejeter');
        Route::delete('/{publicite}',              [AdminPublicite::class, 'destroy'])->name('destroy');
    });

    // Signalements
    Route::middleware('permission:'.Permission::MANAGE_SIGNALEMENTS)->prefix('signalements')->name('signalements.')->group(function () {
        Route::get('/',                   [SignalementController::class, 'index'])->name('list');
        Route::get('/{signalement}',      [SignalementController::class, 'show'])->name('detail');
        Route::patch('/{signalement}/statut',[SignalementController::class, 'updateStatut'])->name('statut');
    });

    // Statistiques
    Route::middleware('permission:'.Permission::VIEW_STATISTIQUES)->group(function () {
        Route::get('/statistiques',          [AdminStat::class, 'index'])->name('statistiques');
        Route::get('/statistiques/terminaux',[AdminStat::class, 'terminaux'])->name('statistiques.terminaux');
    });

    // Paramètres
    Route::middleware('permission:'.Permission::MANAGE_PARAMETRES)->group(function () {
        Route::get('/parametres',  [AdminParametre::class, 'index'])->name('parametres');
        Route::put('/parametres',  [AdminParametre::class, 'update'])->name('parametres.update');

        // SEO
        Route::prefix('seo')->name('seo.')->group(function () {
            Route::get('/',                      [AdminSeo::class, 'index'])->name('index');
            Route::put('/global',                [AdminSeo::class, 'updateGlobal'])->name('global.update');
            Route::put('/pages/{seoPage}',       [AdminSeo::class, 'updatePage'])->name('page.update');
        });
    });

    // Référentiels RH (compétences, métiers, contrats, secteurs, langues, niveaux)
    Route::middleware('permission:'.Permission::MANAGE_REFERENTIELS)->group(function () {

        Route::prefix('competences')->name('competences.')->group(function () {
            Route::get('/',                      [AdminCompetences::class, 'index'])->name('index');
            Route::get('/creer',                 [AdminCompetences::class, 'create'])->name('create');
            Route::post('/',                     [AdminCompetences::class, 'store'])->name('store');
            Route::get('/{competence}/modifier', [AdminCompetences::class, 'edit'])->name('edit');
            Route::put('/{competence}',          [AdminCompetences::class, 'update'])->name('update');
            Route::delete('/{competence}',       [AdminCompetences::class, 'destroy'])->name('destroy');
        });

        Route::prefix('metiers')->name('metiers.')->group(function () {
            Route::get('/',                  [AdminMetiers::class, 'index'])->name('index');
            Route::get('/creer',             [AdminMetiers::class, 'create'])->name('create');
            Route::post('/',                 [AdminMetiers::class, 'store'])->name('store');
            Route::get('/{metier}/modifier', [AdminMetiers::class, 'edit'])->name('edit');
            Route::put('/{metier}',          [AdminMetiers::class, 'update'])->name('update');
            Route::delete('/{metier}',       [AdminMetiers::class, 'destroy'])->name('destroy');
        });

        Route::prefix('types-contrat')->name('types-contrat.')->group(function () {
            Route::get('/',                       [AdminTypeContrats::class, 'index'])->name('index');
            Route::get('/creer',                  [AdminTypeContrats::class, 'create'])->name('create');
            Route::post('/',                      [AdminTypeContrats::class, 'store'])->name('store');
            Route::get('/{typeContrat}/modifier', [AdminTypeContrats::class, 'edit'])->name('edit');
            Route::put('/{typeContrat}',          [AdminTypeContrats::class, 'update'])->name('update');
            Route::delete('/{typeContrat}',       [AdminTypeContrats::class, 'destroy'])->name('destroy');
        });

        Route::prefix('secteurs-activite')->name('secteurs-activite.')->group(function () {
            Route::get('/',                           [AdminSecteursActivite::class, 'index'])->name('index');
            Route::get('/creer',                      [AdminSecteursActivite::class, 'create'])->name('create');
            Route::post('/',                          [AdminSecteursActivite::class, 'store'])->name('store');
            Route::get('/{secteurActivite}/modifier', [AdminSecteursActivite::class, 'edit'])->name('edit');
            Route::put('/{secteurActivite}',          [AdminSecteursActivite::class, 'update'])->name('update');
            Route::delete('/{secteurActivite}',       [AdminSecteursActivite::class, 'destroy'])->name('destroy');
        });

        Route::prefix('langues')->name('langues.')->group(function () {
            Route::get('/',                   [AdminLangues::class, 'index'])->name('index');
            Route::get('/creer',              [AdminLangues::class, 'create'])->name('create');
            Route::post('/',                  [AdminLangues::class, 'store'])->name('store');
            Route::get('/{langue}/modifier',  [AdminLangues::class, 'edit'])->name('edit');
            Route::put('/{langue}',           [AdminLangues::class, 'update'])->name('update');
            Route::delete('/{langue}',        [AdminLangues::class, 'destroy'])->name('destroy');
        });

        Route::prefix('niveaux-langue')->name('niveaux-langue.')->group(function () {
            Route::get('/',                        [AdminNiveauxLangue::class, 'index'])->name('index');
            Route::get('/creer',                   [AdminNiveauxLangue::class, 'create'])->name('create');
            Route::post('/',                       [AdminNiveauxLangue::class, 'store'])->name('store');
            Route::get('/{niveauLangue}/modifier', [AdminNiveauxLangue::class, 'edit'])->name('edit');
            Route::put('/{niveauLangue}',          [AdminNiveauxLangue::class, 'update'])->name('update');
            Route::delete('/{niveauLangue}',       [AdminNiveauxLangue::class, 'destroy'])->name('destroy');
        });

        Route::prefix('niveaux-etude')->name('niveaux-etude.')->group(function () {
            Route::get('/',                       [AdminNiveauxEtude::class, 'index'])->name('index');
            Route::get('/creer',                  [AdminNiveauxEtude::class, 'create'])->name('create');
            Route::post('/',                      [AdminNiveauxEtude::class, 'store'])->name('store');
            Route::get('/{niveauEtude}/modifier', [AdminNiveauxEtude::class, 'edit'])->name('edit');
            Route::put('/{niveauEtude}',          [AdminNiveauxEtude::class, 'update'])->name('update');
            Route::delete('/{niveauEtude}',       [AdminNiveauxEtude::class, 'destroy'])->name('destroy');
        });

        Route::prefix('niveaux-experience')->name('niveaux-experience.')->group(function () {
            Route::get('/',                           [AdminNiveauxExperience::class, 'index'])->name('index');
            Route::get('/creer',                      [AdminNiveauxExperience::class, 'create'])->name('create');
            Route::post('/',                          [AdminNiveauxExperience::class, 'store'])->name('store');
            Route::get('/{niveauExperience}/modifier',[AdminNiveauxExperience::class, 'edit'])->name('edit');
            Route::put('/{niveauExperience}',         [AdminNiveauxExperience::class, 'update'])->name('update');
            Route::delete('/{niveauExperience}',      [AdminNiveauxExperience::class, 'destroy'])->name('destroy');
        });

        Route::prefix('disponibilites')->name('disponibilites.')->group(function () {
            Route::get('/',                            [AdminDisponibilites::class, 'index'])->name('index');
            Route::get('/creer',                       [AdminDisponibilites::class, 'create'])->name('create');
            Route::post('/',                           [AdminDisponibilites::class, 'store'])->name('store');
            Route::get('/{disponibilite}/modifier',    [AdminDisponibilites::class, 'edit'])->name('edit');
            Route::put('/{disponibilite}',             [AdminDisponibilites::class, 'update'])->name('update');
            Route::delete('/{disponibilite}',          [AdminDisponibilites::class, 'destroy'])->name('destroy');
        });

        Route::prefix('regions')->name('regions.')->group(function () {
            Route::get('/',                   [AdminRegions::class, 'index'])->name('index');
            Route::get('/creer',              [AdminRegions::class, 'create'])->name('create');
            Route::post('/',                  [AdminRegions::class, 'store'])->name('store');
            Route::get('/{region}/modifier',  [AdminRegions::class, 'edit'])->name('edit');
            Route::put('/{region}',           [AdminRegions::class, 'update'])->name('update');
            Route::delete('/{region}',        [AdminRegions::class, 'destroy'])->name('destroy');
        });

    });

    // Partenaires / logos de confiance
    Route::middleware('permission:'.Permission::MANAGE_PARAMETRES)->prefix('partenaires')->name('partenaires.')->group(function () {
        Route::get('/',                       [AdminPartenaire::class, 'index'])->name('index');
        Route::post('/',                      [AdminPartenaire::class, 'store'])->name('store');
        Route::put('/{partenaire}',           [AdminPartenaire::class, 'update'])->name('update');
        Route::delete('/{partenaire}',        [AdminPartenaire::class, 'destroy'])->name('destroy');
    });

    // Notifications admin
    Route::get('/notifications',          [AdminNotification::class, 'index'])->name('notifications');
    Route::post('/notifications/marquer', function () {
        auth()->user()->notifications()->where('lu', false)->update(['lu' => true]);
        return back()->with('success', 'Notifications marquées comme lues.');
    })->name('notifications.lues');

    // Newsletter admin
    Route::prefix('newsletter')->name('newsletter.')->group(function () {
        Route::get('/',                          [AdminNewsletter::class, 'index'])->name('index');
        Route::get('/export',                    [AdminNewsletter::class, 'export'])->name('export');
        Route::patch('/{subscriber}/toggle',     [AdminNewsletter::class, 'toggleStatut'])->name('toggle');
        Route::delete('/{subscriber}',           [AdminNewsletter::class, 'destroy'])->name('destroy');
    });

    // Gestion des rôles et permissions (super admin uniquement)
    Route::prefix('permissions')->name('permissions.')->group(function () {
        Route::get('/',                                [PermissionController::class, 'index'])->name('index');
        Route::put('/roles/{role}',                    [PermissionController::class, 'updateRole'])->name('role.update');
        Route::put('/users/{user}/role',               [PermissionController::class, 'updateUserRole'])->name('user.role');
        Route::post('/users/{user}/give',              [PermissionController::class, 'givePermissionToUser'])->name('user.give');
        Route::delete('/users/{user}/revoke',          [PermissionController::class, 'revokePermissionFromUser'])->name('user.revoke');
    });
});






